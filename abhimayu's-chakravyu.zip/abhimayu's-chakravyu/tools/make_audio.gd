extends SceneTree
## Generates every sound effect and the ambient drone as 16-bit mono WAVs.
## Run once from the project root:
##   godot --headless --script res://tools/make_audio.gd
## The output lands in assets/audio/ and is then imported by the editor.

const RATE := 44100
const OUT := "res://assets/audio"

func _initialize() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUT))
	_save("jump", _make_jump())
	_save("land", _make_land())
	_save("levitate", _make_levitate())
	_save("damage", _make_damage())
	_save("death", _make_death())
	_save("ring", _make_ring())
	_save("checkpoint", _make_checkpoint())
	_save("gate", _make_gate())
	_save("boss_hit", _make_boss_hit())
	_save("boss_defeat", _make_boss_defeat())
	_save("boss_spawn", _make_boss_spawn())
	_save("shoot", _make_shoot())
	_save("orb", _make_orb())
	_save("crumble", _make_crumble())
	_save("ui_open", _make_ui(true))
	_save("ui_close", _make_ui(false))
	_save("victory", _make_victory())
	_save("ambient", _make_ambient(), 0.55, false)
	print("Audio written to ", OUT)
	quit()

# ---------------------------------------------------------------- primitives

func _buf(seconds: float) -> PackedFloat32Array:
	var b := PackedFloat32Array()
	b.resize(int(seconds * float(RATE)))
	return b

func _tone(b: PackedFloat32Array, t0: float, dur: float, f0: float, f1: float,
		amp: float, decay: float, harm: Array = [1.0], attack := 0.005) -> void:
	var start := int(t0 * float(RATE))
	var n := mini(int(dur * float(RATE)), b.size() - start)
	if n <= 0:
		return
	var phase := 0.0
	for i in n:
		var t := float(i) / float(RATE)
		var f := lerpf(f0, f1, clampf(t / dur, 0.0, 1.0))
		phase += TAU * f / float(RATE)
		var env := amp * exp(-decay * t)
		if t < attack:
			env *= t / attack
		var s := 0.0
		for k in harm.size():
			s += sin(phase * float(k + 1)) * float(harm[k])
		b[start + i] += s * env

func _partials(b: PackedFloat32Array, t0: float, base: float, ratios: Array,
		amps: Array, dur: float, decay: float, attack := 0.003) -> void:
	for i in ratios.size():
		var f := base * float(ratios[i])
		_tone(b, t0, dur, f, f, float(amps[i]), decay, [1.0, 0.18], attack)

func _noise(b: PackedFloat32Array, t0: float, dur: float, amp: float, decay: float,
		cutoff := 0.25, attack := 0.003, seed := 7, highpass := false,
		cutoff_end := 0.0) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var start := int(t0 * float(RATE))
	var n := mini(int(dur * float(RATE)), b.size() - start)
	if n <= 0:
		return
	var lp := 0.0
	for i in n:
		var t := float(i) / float(RATE)
		var x := rng.randf_range(-1.0, 1.0)
		var cut := cutoff
		if cutoff_end > 0.0:
			cut = lerpf(cutoff, cutoff_end, t / dur)
		lp += (x - lp) * cut
		var sample: float = x - lp if highpass else lp
		var env := amp * exp(-decay * t)
		if t < attack:
			env *= t / attack
		b[start + i] += sample * env

func _reverb(b: PackedFloat32Array, delay := 0.085, feedback := 0.32, mix := 0.42) -> void:
	var d := int(delay * float(RATE))
	if d <= 0:
		return
	for i in range(d, b.size()):
		b[i] += b[i - d] * feedback * mix

func _save(name: String, b: PackedFloat32Array, peak := 0.86, fade := true) -> void:
	var maxv := 0.0001
	for v in b:
		maxv = maxf(maxv, absf(v))
	var gain := peak / maxv
	var n := b.size()
	var fade_in := int(0.003 * float(RATE))
	var fade_out := int(0.012 * float(RATE))
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	for i in n:
		var s := b[i] * gain
		if fade:
			if i < fade_in:
				s *= float(i) / float(fade_in)
			elif i > n - fade_out:
				s *= float(n - i) / float(fade_out)
		bytes.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 32767.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = bytes
	var path := OUT + "/" + name + ".wav"
	var err := wav.save_to_wav(ProjectSettings.globalize_path(path))
	print("  ", name, ".wav  ", "ok" if err == OK else "ERR %d" % err)

# ------------------------------------------------------------------- sounds

func _make_jump() -> PackedFloat32Array:
	var b := _buf(0.32)
	_tone(b, 0.0, 0.28, 290.0, 720.0, 0.55, 7.5, [1.0, 0.34, 0.12])
	_noise(b, 0.0, 0.22, 0.16, 12.0, 0.35, 0.002, 11, true)
	return b

func _make_land() -> PackedFloat32Array:
	var b := _buf(0.28)
	_tone(b, 0.0, 0.24, 150.0, 52.0, 0.8, 14.0, [1.0, 0.55, 0.22])
	_noise(b, 0.0, 0.16, 0.30, 20.0, 0.10, 0.001, 12)
	_noise(b, 0.0, 0.06, 0.14, 40.0, 0.65, 0.001, 13, true)
	return b

func _make_levitate() -> PackedFloat32Array:
	var b := _buf(0.95)
	_noise(b, 0.0, 0.9, 0.14, 1.2, 0.03, 0.22, 21, false, 0.30)
	_tone(b, 0.0, 0.9, 620.0, 1240.0, 0.10, 1.6, [1.0, 0.3, 0.12], 0.2)
	_tone(b, 0.12, 0.75, 930.0, 1600.0, 0.06, 2.4, [1.0, 0.25], 0.26)
	_reverb(b, 0.06, 0.22, 0.3)
	return b

func _make_damage() -> PackedFloat32Array:
	var b := _buf(0.42)
	_tone(b, 0.0, 0.34, 220.0, 64.0, 0.75, 9.0, [1.0, 0.7, 0.34, 0.18])
	_noise(b, 0.0, 0.26, 0.34, 13.0, 0.14, 0.001, 31)
	_noise(b, 0.0, 0.10, 0.20, 28.0, 0.55, 0.001, 32, true)
	return b

func _make_death() -> PackedFloat32Array:
	var b := _buf(1.7)
	_tone(b, 0.0, 1.5, 110.0, 32.0, 0.85, 2.6, [1.0, 0.6, 0.35, 0.2])
	_noise(b, 0.0, 1.2, 0.35, 3.2, 0.05, 0.002, 41)
	_partials(b, 0.05, 196.0, [1.0, 2.76, 5.4, 8.93], [0.35, 0.2, 0.12, 0.07], 1.3, 2.4)
	_reverb(b, 0.11, 0.34, 0.35)
	return b

func _make_ring() -> PackedFloat32Array:
	var b := _buf(1.8)
	var notes := [587.33, 880.0, 1174.66, 1479.98]
	for i in notes.size():
		var t := float(i) * 0.095
		_tone(b, t, 1.5 - t, notes[i], notes[i], 0.42 - 0.05 * float(i), 2.7, [1.0, 0.5, 0.26, 0.12])
		_tone(b, t, 0.9, notes[i] * 2.01, notes[i] * 2.0, 0.07, 4.0, [1.0, 0.2])
	_tone(b, 0.34, 1.3, 2349.3, 2349.3, 0.12, 3.4, [1.0, 0.3])
	_reverb(b, 0.12, 0.38, 0.5)
	return b

func _make_checkpoint() -> PackedFloat32Array:
	var b := _buf(2.6)
	_partials(b, 0.0, 196.0, [1.0, 2.0, 2.76, 5.4, 8.93, 13.3],
		[0.8, 0.55, 0.4, 0.26, 0.15, 0.08], 2.4, 1.35)
	_tone(b, 0.0, 2.0, 392.0, 392.0, 0.10, 1.6, [1.0, 0.4])
	_reverb(b, 0.14, 0.36, 0.5)
	return b

func _make_gate() -> PackedFloat32Array:
	var b := _buf(1.5)
	_noise(b, 0.0, 0.9, 0.16, 1.4, 0.02, 0.15, 51, false, 0.32)
	_tone(b, 0.28, 1.1, 392.0, 587.33, 0.30, 2.2, [1.0, 0.5, 0.2])
	_tone(b, 0.36, 1.0, 880.0, 1174.66, 0.16, 2.8, [1.0, 0.3])
	_reverb(b, 0.1, 0.3, 0.4)
	return b

func _make_boss_hit() -> PackedFloat32Array:
	var b := _buf(0.8)
	_partials(b, 0.0, 233.08, [1.0, 2.76, 5.4, 8.93, 13.3],
		[0.7, 0.45, 0.3, 0.18, 0.1], 0.7, 5.2)
	_noise(b, 0.0, 0.3, 0.3, 12.0, 0.5, 0.001, 61, true)
	_noise(b, 0.0, 0.12, 0.22, 24.0, 0.2, 0.001, 62)
	_reverb(b, 0.07, 0.3, 0.4)
	return b

func _make_boss_defeat() -> PackedFloat32Array:
	var b := _buf(2.6)
	_tone(b, 0.0, 2.4, 78.0, 26.0, 0.9, 1.7, [1.0, 0.65, 0.4, 0.24])
	_noise(b, 0.0, 2.2, 0.4, 1.9, 0.07, 0.002, 71)
	_noise(b, 0.0, 0.35, 0.3, 8.0, 0.6, 0.001, 72, true)
	_partials(b, 0.25, 174.61, [1.0, 2.76, 5.4, 8.93], [0.3, 0.2, 0.12, 0.07], 1.4, 3.0)
	_partials(b, 0.62, 261.63, [1.0, 2.76, 5.4], [0.2, 0.13, 0.08], 1.2, 3.4)
	_reverb(b, 0.13, 0.36, 0.45)
	return b

func _make_boss_spawn() -> PackedFloat32Array:
	var b := _buf(2.4)
	_tone(b, 0.0, 2.2, 42.0, 58.0, 0.7, 0.5, [1.0, 0.6, 0.4, 0.25, 0.15])
	_tone(b, 0.0, 2.2, 43.2, 59.0, 0.4, 0.5, [1.0, 0.5, 0.3])
	_noise(b, 0.0, 2.0, 0.20, 0.6, 0.02, 0.3, 81, false, 0.12)
	_tone(b, 0.4, 1.6, 110.0, 146.83, 0.18, 1.4, [1.0, 0.5, 0.3], 0.3)
	_reverb(b, 0.12, 0.34, 0.4)
	return b

func _make_shoot() -> PackedFloat32Array:
	var b := _buf(0.24)
	_tone(b, 0.0, 0.2, 520.0, 170.0, 0.45, 13.0, [1.0, 0.5, 0.25])
	_noise(b, 0.0, 0.1, 0.25, 26.0, 0.65, 0.001, 91, true)
	_noise(b, 0.0, 0.14, 0.12, 18.0, 0.1, 0.001, 92)
	return b

func _make_orb() -> PackedFloat32Array:
	var b := _buf(0.55)
	_noise(b, 0.0, 0.5, 0.20, 2.0, 0.03, 0.06, 101, false, 0.28)
	_noise(b, 0.05, 0.45, 0.10, 2.4, 0.30, 0.08, 102, true, 0.06)
	_tone(b, 0.04, 0.4, 300.0, 760.0, 0.10, 3.0, [1.0, 0.35], 0.08)
	_reverb(b, 0.08, 0.25, 0.3)
	return b

func _make_crumble() -> PackedFloat32Array:
	var b := _buf(1.0)
	_tone(b, 0.0, 0.5, 130.0, 45.0, 0.55, 7.0, [1.0, 0.55, 0.3])
	for i in 5:
		_noise(b, 0.02 + float(i) * 0.09, 0.14, 0.22, 12.0, 0.42, 0.002, 110 + i, true)
	_noise(b, 0.0, 0.8, 0.28, 2.6, 0.08, 0.002, 120)
	_reverb(b, 0.09, 0.24, 0.28)
	return b

func _make_ui(open: bool) -> PackedFloat32Array:
	var b := _buf(0.18)
	var base := 660.0 if open else 494.0
	_tone(b, 0.0, 0.14, base, base * 1.12, 0.28, 22.0, [1.0, 0.3])
	_tone(b, 0.03, 0.12, base * 1.5, base * 1.5, 0.10, 26.0, [1.0])
	_noise(b, 0.0, 0.03, 0.06, 50.0, 0.7, 0.001, 131, true)
	return b

func _make_victory() -> PackedFloat32Array:
	var b := _buf(4.6)
	var chord := [146.83, 220.0, 293.66, 369.99, 440.0, 587.33]
	for i in chord.size():
		var t := float(i) * 0.09
		_tone(b, t, 4.0 - t, chord[i], chord[i], 0.30 - 0.025 * float(i), 0.55,
			[1.0, 0.5, 0.28, 0.14, 0.08], 0.25)
	for i in 4:
		_tone(b, float(i) * 1.15, 1.2, 587.33 * 2.0, 587.33 * 2.0, 0.08, 2.0, [1.0, 0.3], 0.02)
	_tone(b, 0.1, 3.6, 1174.66, 1174.66, 0.07, 1.1, [1.0, 0.3])
	_reverb(b, 0.16, 0.4, 0.5)
	return b

func _make_ambient() -> PackedFloat32Array:
	var dur := 16.0
	var n := int(dur * float(RATE))
	var b := PackedFloat32Array()
	b.resize(n)
	# Frequencies are exact integer cycle counts over the loop, so it is seamless.
	var voices := [
		[1175.0 / dur, 0.36, 0.0, 1.0],   # D2
		[1760.0 / dur, 0.16, 1.7, 2.0],   # A2
		[2349.0 / dur, 0.15, 3.1, 0.8],   # D3
		[2938.0 / dur, 0.06, 4.6, 0.5],   # F#3
		[3520.0 / dur, 0.05, 5.4, 0.4],   # A3
		[4698.0 / dur, 0.025, 2.2, 0.3],  # D4
	]
	for v in voices:
		var freq: float = v[0]
		var amp: float = v[1]
		var ph: float = v[2]
		var mod: float = v[3]
		for i in n:
			var t := float(i) / float(RATE)
			var swell := 0.70 + 0.18 * sin(TAU * t / dur * 2.0 + ph) \
				+ 0.12 * sin(TAU * t / dur * 3.0 + ph * 1.7)
			var s := sin(TAU * freq * t + ph) \
				+ 0.34 * sin(TAU * freq * 2.0 * t + ph * 0.6) \
				+ 0.16 * sin(TAU * freq * 3.0 * t + ph * 1.3)
			b[i] += s * amp * swell * mod
	return b

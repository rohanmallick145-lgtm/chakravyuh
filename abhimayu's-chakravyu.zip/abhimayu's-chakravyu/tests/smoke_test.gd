extends Node
## Headless smoke test. Run it with:
##   godot --headless --path . res://tests/smoke_test.tscn
## It boots the real game scene, drives a few inputs and verifies the core
## systems: movement, ring -> HP tradeoff, level transition, boss, victory.

var _fails := 0

func _ready() -> void:
	_run()

func _check(ok: bool, label: String) -> void:
	if ok:
		print("PASS  ", label)
	else:
		_fails += 1
		printerr("FAIL  ", label)

func _wait(seconds: float) -> void:
	await get_tree().create_timer(seconds, true, false, true).timeout

## Poll a condition in real time instead of guessing a fixed delay.
func _wait_until(predicate: Callable, limit := 8.0) -> bool:
	var waited := 0.0
	while waited < limit:
		if predicate.call():
			return true
		await _wait(0.1)
		waited += 0.1
	return predicate.call()

func _key(code: Key, pressed: bool) -> InputEventKey:
	var e := InputEventKey.new()
	e.keycode = code
	e.physical_keycode = code
	e.pressed = pressed
	return e

func _wait_for_dialogue(game: Node, limit := 4.0) -> bool:
	var dlg = game.get_node("DialogueLayer")
	var waited := 0.0
	while not dlg.is_open and waited < limit:
		await _wait(0.1)
		waited += 0.1
	return dlg.is_open

func _close_dialogue(game: Node) -> void:
	var dlg = game.get_node("DialogueLayer")
	if dlg.is_open:
		dlg.call("_close")
	await _wait(0.15)

func _run() -> void:
	print("=== Abhimanyu's Chakravyuha smoke test ===")
	var game = load("res://scenes/game.tscn").instantiate()
	add_child(game)
	await _wait(1.0)

	_check(GameState.current_round == 1, "round 1 loaded")
	_check(game.level != null, "level node instantiated")
	_check(Sfx.has_stream("jump") and Sfx.has_stream("ambient"), "audio streams loaded")
	_check(game.level.get("sky") != null, "painted sky layer built")
	_check(await _wait_for_dialogue(game), "round intro dialogue opens")
	var intro_portrait = game.get_node("DialogueLayer").portrait.texture
	_check(intro_portrait != null and intro_portrait.resource_path.contains("elders.png"),
		"elder speaker uses the supplied portrait")
	var karna_portrait = game.get_node("DialogueLayer").call("_portrait_for", "Karna")
	_check(karna_portrait != null and karna_portrait.resource_path.contains("karna.png"),
		"Karna uses the supplied portrait")
	await _close_dialogue(game)
	await _wait(0.4)

	var player = game.player
	var level = game.level
	_check(player.input_enabled, "player input enabled after intro")
	_check(level.ring != null, "celestial ring exists")

	# --- painted enemy sprite ---------------------------------------------
	var patroller_art := false
	for child in level.get_children():
		var child_script = child.get_script()
		if child_script != null and str(child_script.resource_path).ends_with("patroller.gd"):
			var art = child.get("_sprite")
			if art is Sprite2D and art.texture != null and art.texture.resource_path.contains("asura.png"):
				patroller_art = true
	_check(patroller_art, "patroller uses the supplied enemy sprite")

	# --- rolling movement -------------------------------------------------
	var start_x: float = player.global_position.x
	Input.parse_input_event(_key(KEY_D, true))
	await _wait(0.9)
	Input.parse_input_event(_key(KEY_D, false))
	await _wait(0.1)
	_check(player.global_position.x > start_x + 30.0, "rolling right moves Arjun")
	await _wait(0.4)

	# --- jump + levitation ------------------------------------------------
	var air_y: float = player.global_position.y
	Input.parse_input_event(_key(KEY_W, true))
	await _wait(0.75)
	Input.parse_input_event(_key(KEY_W, false))
	_check(player.global_position.y < air_y - 60.0, "hold W to jump and levitate")
	await _wait(1.4)

	# --- checkpoint: slow-motion story beat + respawn point ----------------
	var checkpoints: Array = level.get("_checkpoints")
	_check(checkpoints.size() > 0, "round 1 has a checkpoint")
	if checkpoints.size() > 0:
		var cp: Node = checkpoints[0]
		player.global_position = cp.global_position + Vector2(0, -20)
		player.linear_velocity = Vector2.ZERO
		await _wait(0.6)
		_check(await _wait_for_dialogue(game), "checkpoint story beat opens")
		var checkpoint_portrait = game.get_node("DialogueLayer").portrait.texture
		_check(checkpoint_portrait != null and checkpoint_portrait.resource_path.contains("warrior.svg"),
			"younger speaker uses the warrior portrait")
		_check(is_equal_approx(Engine.time_scale, 0.22), "checkpoint triggers slow motion")
		await _close_dialogue(game)
		await _wait(0.8)
		_check(is_equal_approx(Engine.time_scale, 1.0), "time scale restored after popup")
		_check(GameState.has_seen_checkpoint(1, 0), "checkpoint story remembered")

	# --- ring pickup / HP cap tradeoff ------------------------------------
	GameState.heal_full()
	var hp_before: float = GameState.hp
	player.global_position = level.ring.global_position
	player.linear_velocity = Vector2.ZERO
	await _wait(0.6)
	_check(GameState.ring_count == 1, "ring picked up (count 1)")
	_check(absf(GameState.max_hp - 91.6667) < 0.25, "max HP dropped by 1/12")
	_check(GameState.hp < hp_before, "current HP clipped by new cap")
	_check(level.exit_portal.unlocked, "exit gate unlocks after ring")

	# --- death -> respawn keeps the claimed ring, heals to the cap --------
	GameState.damage(9999.0)
	await _wait_until(func() -> bool:
		return is_equal_approx(GameState.hp, GameState.max_hp) and player.input_enabled
	)
	_check(GameState.current_round == 1, "death respawns in the same round")
	_check(is_equal_approx(GameState.hp, GameState.max_hp), "respawn restores HP to the cap")
	_check(is_equal_approx(GameState.max_hp, 91.6667), "claimed ring survives death")
	_check(game.level.ring == null, "claimed ring does not respawn")
	_check(game.level.exit_portal.unlocked, "gate stays unlocked after respawn")
	_check(player.input_enabled, "input re-enabled after respawn")
	_check(not game.get_node("DialogueLayer").is_open, "story popups do not repeat")
	player.global_position = game.level.exit_portal.global_position + Vector2(0, -20)
	player.linear_velocity = Vector2.ZERO
	await _wait(2.0)
	_check(GameState.current_round == 2, "exit gate advances to round 2")
	_check(await _wait_for_dialogue(game), "round 2 intro opens")
	await _close_dialogue(game)

	# --- jump to the final round at six rings -----------------------------
	GameState.claimed_rounds = [1, 2, 3, 4, 5, 6]
	GameState.ring_count = 6
	game.call("_load_round", 7, false)
	await _wait(2.0)
	_check(GameState.current_round == 7, "round 7 loaded")
	_check(is_equal_approx(GameState.max_hp, 50.0) and is_equal_approx(GameState.hp, 50.0),
		"round 7 starts at exactly 50 / 50 HP")
	_check(game.level.is_dark, "round 7 runs in darkness")
	_check(game.level.boss != null, "Chakravyuha boss spawned")
	_check(await _wait_for_dialogue(game), "round 7 intro opens")
	var final_portrait = game.get_node("DialogueLayer").portrait.texture
	_check(final_portrait != null and final_portrait.resource_path.contains("krishna.png"),
		"Krishna uses the final-round portrait")
	await _close_dialogue(game)

	# --- boss defeat spawns the seventh ring ------------------------------
	await _wait(5.0)
	_check(game.level.boss != null and is_instance_valid(game.level.boss),
		"boss survives its attack cycle")
	if game.level.boss != null:
		game.level.boss.call("_die")
	await _wait(1.4)
	_check(game.level.ring != null, "seventh ring spawns after boss dies")
	if game.level.ring != null:
		player.global_position = game.level.ring.global_position
		player.linear_velocity = Vector2.ZERO
	await _wait(1.2)
	_check(GameState.ring_count == 7, "seventh ring claimed")
	_check(absf(GameState.max_hp - 41.6667) < 0.25, "max HP after 7 rings")
	await _wait_for_dialogue(game)
	await _close_dialogue(game)

	# --- final gate -> victory -------------------------------------------
	var exit_portal = game.level.exit_portal
	player.global_position = exit_portal.global_position + Vector2(0, -20)
	player.linear_velocity = Vector2.ZERO
	await _wait(2.0)
	_check(await _wait_for_dialogue(game), "victory dialogue opens")
	await _close_dialogue(game)
	await _wait(0.4)
	_check(game.hud.victory, "victory screen shown")

	print("=== %s (%d failure%s) ===" % [
		"ALL CHECKS PASSED" if _fails == 0 else "SMOKE TEST FAILED",
		_fails,
		"" if _fails == 1 else "s",
	])
	get_tree().quit(0 if _fails == 0 else 1)

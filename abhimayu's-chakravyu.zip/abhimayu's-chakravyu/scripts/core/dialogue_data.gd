class_name DialogueData
extends RefCounted
## All story text lives here so you can rewrite the narrative without touching
## gameplay code. Add/remove rounds freely; ids are 1..7.

const ROUND_NAMES := {
	1: "Drona's Trial",
	2: "The Flames of Khandava",
	3: "Shakuni's Traps",
	4: "Bhishma's Arrows",
	5: "The Turning Wheel",
	6: "Karna's Solar Duel",
	7: "The Chakravyuha",
}

const ROUND_SUBTITLES := {
	1: "Round I — The First Ring",
	2: "Round II — Ashes and Aim",
	3: "Round III — The Loaded Dice",
	4: "Round IV — Oathbound Arrows",
	5: "Round V — Enter the Wheel",
	6: "Round VI — Face the Sun",
	7: "Round VII — The Seventh Ring",
}

## Shown as a full pause-screen popup at the start of every round.
const round_dialogues := {
	1: {
		"speaker": "Dronacharya",
		"text": "Take this first ring, Arjun. Let celestial fire guide your hand... but know this: every gift of the heavens is paid for in mortal blood. Claim it, and a piece of your life is mine.",
	},
	2: {
		"speaker": "Dronacharya",
		"text": "The flames of Khandava test more than your aim. They test what you are willing to burn. The second ring waits beyond the fire — and your frame grows thinner.",
	},
	3: {
		"speaker": "Shakuni",
		"text": "Every path is a lie, prince. I have loaded the dice and salted the earth. Step where you like — the fall is already written.",
	},
	4: {
		"speaker": "Bhishma",
		"text": "I have sworn my arrows to a doomed throne, and my oath does not bend. Do not expect mercy, child. Expect only the next arrow.",
	},
	5: {
		"speaker": "Dronacharya",
		"text": "The Chakravyuha turns without end. Enter it, and the wheel will close behind you. Six gates. Six wounds. Do not stop moving.",
	},
	6: {
		"speaker": "Karna",
		"text": "The sun sees all, Arjun — including the fear you hide beneath your golden rings. Face me at noon. One of us will be ash by dusk.",
	},
	7: {
		"speaker": "Krishna",
		"text": "Six rings. Six wounds in your mortal frame. You enter this darkness with half a life and a broken shell. The seventh ring waits at the heart of the wheel. Finish it.",
	},
}

const CHECKPOINT_DEFAULT := {
	"speaker": "Arjun",
	"text": "The ring hums against my ribs. It is heavier than it looks... and my chest aches where the light touches.",
}

## Shown once when the final ring is claimed.
const FINAL_RING := {
	"speaker": "Krishna",
	"text": "The wheel is broken. The seventh ring is yours — and with it, what remains of your mortal frame. Rise, Arjun. The dark has nothing left to take.",
}

const VICTORY := {
	"speaker": "Krishna",
	"text": "Seven rings. One broken wheel. You were never meant to survive this, child — and yet here you stand, more light than flesh. The age turns. Walk into it.",
}

const DEATH_HINTS := [
	"The wheel does not mourn. Rise again.",
	"Your rings flicker, but they do not die.",
	"Half a life is still a life. Try once more.",
]

static func get_round_name(index: int) -> String:
	return ROUND_NAMES.get(index, "Unknown Round")

static func get_round_subtitle(index: int) -> String:
	return ROUND_SUBTITLES.get(index, "")

static func get_round_dialogue(index: int) -> Dictionary:
	return round_dialogues.get(index, CHECKPOINT_DEFAULT)

static func get_death_hint() -> String:
	return DEATH_HINTS[randi() % DEATH_HINTS.size()]

extends Node
## Persistent run state: rings, the HP cap they devour, and levitation power.
## Add this file as the "GameState" autoload (already registered in project.godot).

signal ring_count_changed(count: int, total: int)
signal hp_changed(hp: float, max_hp: float, base_max_hp: float)
signal ring_absorbed(ring_number: int, hp_lost: float)
signal player_died
signal run_reset

const TOTAL_ROUNDS := 7
const MAX_RINGS := 7
const BASE_MAX_HP := 100.0
## 1/12 = 8.333...% of max HP lost per ring. Six rings = exactly 50% HP.
const HP_LOSS_PER_RING := 1.0 / 12.0
## Levitation seconds at zero rings, and the bonus added by each ring.
const BASE_LEVITATION := 0.5
const LEVITATION_PER_RING := 0.35
## Most HP Arjun can ever lose before the final fight (6 rings = 50%).
const FINAL_ROUND := 7

var current_round := 1
var ring_count := 0
var hp := BASE_MAX_HP
var max_hp := BASE_MAX_HP
var deaths := 0
## Rounds whose ring has already been claimed (survives checkpoint reloads).
var claimed_rounds: Array[int] = []
## Checkpoints already seen, keyed "round:index", so story beats never repeat.
var seen_checkpoints: Dictionary = {}

func _ready() -> void:
	reset_run()

func reset_run() -> void:
	current_round = 1
	ring_count = 0
	deaths = 0
	claimed_rounds.clear()
	seen_checkpoints.clear()
	max_hp = _max_hp_for(ring_count)
	hp = max_hp
	ring_count_changed.emit(ring_count, MAX_RINGS)
	hp_changed.emit(hp, max_hp, BASE_MAX_HP)
	run_reset.emit()

## Called by the game manager whenever a level is (re)loaded. Healing to the
## current cap is what makes Round 7 begin at exactly 50 out of 100 HP.
func begin_round(round_index: int) -> void:
	current_round = clampi(round_index, 1, TOTAL_ROUNDS)
	max_hp = _max_hp_for(ring_count)
	hp = max_hp
	hp_changed.emit(hp, max_hp, BASE_MAX_HP)

func _max_hp_for(rings: int) -> float:
	return maxf(1.0, BASE_MAX_HP * (1.0 - float(rings) * HP_LOSS_PER_RING))

## The risk/reward hook: each celestial ring permanently lowers the HP cap.
func gain_ring() -> void:
	if ring_count >= MAX_RINGS:
		return
	var hp_before := hp
	ring_count += 1
	if not claimed_rounds.has(current_round):
		claimed_rounds.append(current_round)
	max_hp = _max_hp_for(ring_count)
	hp = minf(hp, max_hp)
	var lost := maxf(0.0, hp_before - hp)
	ring_count_changed.emit(ring_count, MAX_RINGS)
	hp_changed.emit(hp, max_hp, BASE_MAX_HP)
	ring_absorbed.emit(ring_count, lost)
	if hp <= 0.0:
		player_died.emit()

func has_claimed_ring(round_index: int) -> bool:
	return claimed_rounds.has(round_index)

func mark_checkpoint_seen(round_index: int, checkpoint_index: int) -> void:
	seen_checkpoints["%d:%d" % [round_index, checkpoint_index]] = true

func has_seen_checkpoint(round_index: int, checkpoint_index: int) -> bool:
	return seen_checkpoints.has("%d:%d" % [round_index, checkpoint_index])

func damage(amount: float) -> void:
	if amount <= 0.0 or hp <= 0.0:
		return
	hp = maxf(0.0, hp - amount)
	hp_changed.emit(hp, max_hp, BASE_MAX_HP)
	if hp <= 0.0:
		player_died.emit()

func kill_player() -> void:
	if hp <= 0.0:
		return
	hp = 0.0
	hp_changed.emit(hp, max_hp, BASE_MAX_HP)
	player_died.emit()

func heal(amount: float) -> void:
	hp = minf(max_hp, hp + amount)
	hp_changed.emit(hp, max_hp, BASE_MAX_HP)

func heal_full() -> void:
	hp = max_hp
	hp_changed.emit(hp, max_hp, BASE_MAX_HP)

func register_death() -> void:
	deaths += 1

func levitation_duration() -> float:
	return BASE_LEVITATION + LEVITATION_PER_RING * float(ring_count)

## Higher ring counts also make him float better once levitation is spent.
## At 6 rings, holding W turns a fall into a slow glide.
func float_gravity_scale() -> float:
	return lerpf(0.82, 0.40, clampf(float(ring_count) / float(MAX_RINGS), 0.0, 1.0))

func hp_fraction() -> float:
	return hp / BASE_MAX_HP

func max_hp_fraction() -> float:
	return max_hp / BASE_MAX_HP

func is_final_round() -> bool:
	return current_round >= FINAL_ROUND

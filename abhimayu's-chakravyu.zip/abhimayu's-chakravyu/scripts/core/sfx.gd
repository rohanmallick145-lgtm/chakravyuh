extends Node
## Central audio hub. Loads every generated WAV once, plays one-shots through a
## small round-robin pool, and keeps a looping ambience bed per round.
## Registered as the `Sfx` autoload in project.godot.
##
## Usage: Sfx.play("jump"), Sfx.play("ring", -2.0, 1.04)
##        Sfx.start_ambient(round_index) / Sfx.stop_ambient()

const AUDIO_DIR := "res://assets/audio/"
const POOL_SIZE := 12
const SILENT_DB := -60.0

## Keep this in sync with tools/make_audio.gd.
const SOUND_IDS := [
	"jump", "land", "levitate", "damage", "death", "ring", "checkpoint",
	"gate", "boss_hit", "boss_defeat", "boss_spawn", "shoot", "orb",
	"crumble", "ui_open", "ui_close", "victory", "ambient",
]

var _streams: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []
var _next_player := 0
var _ambient: AudioStreamPlayer = null
var _ambient_tween: Tween = null
var _last_played: Dictionary = {}

func _ready() -> void:
	# Audio must keep running while dialogue pauses the tree.
	process_mode = Node.PROCESS_MODE_ALWAYS
	_load_streams()
	for i in POOL_SIZE:
		var player := AudioStreamPlayer.new()
		player.bus = "SFX"
		player.process_mode = Node.PROCESS_MODE_ALWAYS
		add_child(player)
		_players.append(player)
	_ambient = AudioStreamPlayer.new()
	_ambient.bus = "Music"
	_ambient.volume_db = SILENT_DB
	_ambient.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_ambient)

func _load_streams() -> void:
	for id in SOUND_IDS:
		var path: String = AUDIO_DIR + str(id) + ".wav"
		if not ResourceLoader.exists(path):
			push_warning("Sfx: missing audio file " + path)
			continue
		var stream: AudioStreamWAV = load(path)
		if stream == null:
			continue
		if id == "ambient":
			stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
			stream.loop_begin = 0
			stream.loop_end = int(stream.get_length() * float(stream.mix_rate))
		_streams[id] = stream

func has_stream(id: String) -> bool:
	return _streams.has(id)

## Play a one-shot. `volume_db` is relative to the SFX bus, `pitch` is a
## multiplier (1.0 = original). Repeated identical sounds within 35 ms are
## collapsed so overlapping triggers never phase or clip.
func play(id: String, volume_db := 0.0, pitch := 1.0) -> void:
	if not _streams.has(id):
		return
	var now := Time.get_ticks_msec()
	if _last_played.has(id):
		var last: int = _last_played[id]
		if now - last < 35:
			return
	_last_played[id] = now

	if _players.is_empty():
		return
	var player := _players[_next_player]
	_next_player = (_next_player + 1) % _players.size()
	player.stream = _streams[id]
	player.volume_db = volume_db
	player.pitch_scale = clampf(pitch, 0.35, 2.6)
	player.play()

## Start (or retune) the looping drone. Called on every round load.
func start_ambient(round_index := 1) -> void:
	if _ambient == null or not _streams.has("ambient"):
		return
	var pitch := 1.0
	var target_db := -21.0
	match round_index:
		2:
			pitch = 1.07
			target_db = -19.0
		3:
			pitch = 0.93
			target_db = -21.0
		4:
			pitch = 1.02
			target_db = -22.0
		5:
			pitch = 0.88
			target_db = -20.0
		6:
			pitch = 1.12
			target_db = -19.0
		7:
			pitch = 0.76
			target_db = -15.5
	if not _ambient.playing:
		_ambient.stream = _streams["ambient"]
		_ambient.pitch_scale = pitch
		_ambient.volume_db = SILENT_DB
		_ambient.play()
	_kill_ambient_tween()
	_ambient_tween = create_tween()
	_ambient_tween.set_ignore_time_scale(true)
	_ambient_tween.set_parallel(true)
	_ambient_tween.tween_property(_ambient, "volume_db", target_db, 1.8)
	_ambient_tween.tween_property(_ambient, "pitch_scale", pitch, 1.8)

func stop_ambient(fade := 1.2) -> void:
	if _ambient == null or not _ambient.playing:
		return
	_kill_ambient_tween()
	_ambient_tween = create_tween()
	_ambient_tween.set_ignore_time_scale(true)
	_ambient_tween.tween_property(_ambient, "volume_db", SILENT_DB, maxf(0.05, fade))
	_ambient_tween.tween_callback(_ambient.stop)

func ambient_playing() -> bool:
	return _ambient != null and _ambient.playing

func _kill_ambient_tween() -> void:
	if _ambient_tween and _ambient_tween.is_valid():
		_ambient_tween.kill()
	_ambient_tween = null

extends Node2D
## Game shell: loads rounds, spawns Arjun, routes story triggers, handles
## death/checkpoint flow and the final victory state.

const PLAYER_SCENE := preload("res://scenes/player/arjun.tscn")
const LEVEL_PATH := "res://scenes/levels/level_%02d.tscn"

@onready var container: Node2D = $LevelContainer
@onready var hud = $HUDLayer/HUD
@onready var dialogue: CanvasLayer = $DialogueLayer
@onready var fade: ColorRect = $Overlay/Fade

var player
var level: Node = null

var _checkpoint_position := Vector2.ZERO
var _has_checkpoint := false
var _loading := false
var _transitioning := false
var _victory := false
var _pending_victory := false

func _ready() -> void:
	GameState.reset_run()
	GameState.player_died.connect(_on_player_died)
	dialogue.connect("closed", _on_dialogue_closed)

	player = PLAYER_SCENE.instantiate()
	container.add_child(player)
	player.freeze = true
	player.visible = false
	player.input_enabled = false

	fade.modulate.a = 1.0
	await get_tree().process_frame
	await _load_round(1, false)

func _load_round(index: int, from_respawn: bool) -> void:
	if _loading:
		return
	_loading = true
	player.input_enabled = false
	player.freeze = true

	if level and is_instance_valid(level):
		container.remove_child(level)
		level.queue_free()
		level = null

	GameState.begin_round(index)
	if not from_respawn:
		_has_checkpoint = false
		_checkpoint_position = Vector2.ZERO

	var packed: PackedScene = load(LEVEL_PATH % index)
	if packed == null:
		push_error("Missing level scene: " + (LEVEL_PATH % index))
		_loading = false
		return

	level = packed.instantiate()
	level.set("round_index", index)
	container.add_child(level)
	container.move_child(player, -1)

	level.call("setup_player", player)

	var spawn: Vector2 = level.get("spawn_position")
	if from_respawn and _has_checkpoint:
		spawn = _checkpoint_position
	player.visible = true
	player.reset_at(spawn)
	player.input_enabled = false

	_connect_level(level)
	Sfx.start_ambient(index)
	hud.setup(level, player, index)
	var lvl_data: Dictionary = level.get("data")
	var round_name: String = lvl_data.get("name", DialogueData.get_round_name(index))
	hud.show_round_banner("ROUND %02d" % index, round_name, 3.0)
	var boss_ref = level.get("boss")
	if boss_ref != null:
		hud.set_boss(boss_ref)

	fade.modulate.a = 1.0
	var tween := create_tween()
	tween.tween_property(fade, "modulate:a", 0.0, 0.45)
	await tween.finished
	_loading = false

	if from_respawn:
		player.input_enabled = true
		hud.toast("Checkpoint restored", 2.2)
		return

	await get_tree().create_timer(0.3).timeout
	var intro := DialogueData.get_round_dialogue(index)
	dialogue.call("show_dialogue", intro.get("speaker", "Dronacharya"), intro.get("text", ""), {"pause": true})
	if index == 7:
		hud.toast("Your mortal frame is cracked: you begin at 50 / 50 HP.", 5.0)

func _connect_level(lvl: Node) -> void:
	lvl.connect("ring_collected", _on_ring_collected)
	lvl.connect("checkpoint_reached", _on_checkpoint_reached)
	lvl.connect("exit_reached", _on_exit_reached)
	lvl.connect("boss_spawned", _on_boss_spawned)
	lvl.connect("boss_defeated", _on_boss_defeated)

func _on_dialogue_closed() -> void:
	if _pending_victory:
		_pending_victory = false
		_victory = true
		Sfx.stop_ambient(1.6)
		Sfx.play("victory", -3.0)
		hud.set_victory(true)
		return
	if player and is_instance_valid(player) and not _transitioning and not _victory:
		player.input_enabled = true

func _on_ring_collected(ring_number: int) -> void:
	if GameState.current_round == 7 and ring_number >= 7 and not _pending_victory:
		_pending_victory = false
		player.input_enabled = false
		await get_tree().create_timer(0.65).timeout
		dialogue.call("show_dialogue",
			DialogueData.FINAL_RING.speaker, DialogueData.FINAL_RING.text, {"cinematic": true})

func _on_checkpoint_reached(speaker: String, text: String) -> void:
	if _transitioning or _victory:
		return
	_has_checkpoint = true
	var respawn: Vector2 = level.get("respawn_position")
	_checkpoint_position = respawn
	player.input_enabled = false
	hud.toast("Checkpoint — respawn point set", 2.4)
	dialogue.call("show_dialogue", speaker, text, {"cinematic": true})

func _on_boss_spawned(boss: Node) -> void:
	Sfx.play("boss_spawn", -3.0)
	hud.set_boss(boss)
	hud.toast("THE CHAKRAVYUHA AWAKENS", 3.2)

func _on_boss_defeated() -> void:
	hud.clear_boss()
	hud.toast("The wheel shatters. Claim the seventh ring.", 4.0)

func _on_exit_reached() -> void:
	if _transitioning or _victory:
		return
	_transitioning = true
	player.input_enabled = false
	var tween := create_tween()
	tween.tween_property(fade, "modulate:a", 1.0, 0.4)
	await tween.finished

	if GameState.current_round < 7:
		_transitioning = false
		await _load_round(GameState.current_round + 1, false)
	else:
		_pending_victory = true
		_transitioning = false
		var back := create_tween()
		back.tween_property(fade, "modulate:a", 0.0, 0.35)
		await back.finished
		dialogue.call("show_dialogue",
			DialogueData.VICTORY.speaker, DialogueData.VICTORY.text, {"pause": true})

func _on_player_died() -> void:
	if _transitioning or _victory:
		return
	_transitioning = true
	GameState.register_death()
	player.input_enabled = false
	Engine.time_scale = 0.45
	hud.show_round_banner("ARJUN HAS FALLEN", DialogueData.get_death_hint(), 2.0)
	await get_tree().create_timer(0.95, true, false, true).timeout
	Engine.time_scale = 1.0
	var tween := create_tween()
	tween.tween_property(fade, "modulate:a", 1.0, 0.3)
	await tween.finished
	_transitioning = false
	await _load_round(GameState.current_round, true)

func _unhandled_input(event: InputEvent) -> void:
	if _victory and event.is_action_pressed("ui_accept"):
		get_viewport().set_input_as_handled()
		_victory = false
		_pending_victory = false
		GameState.reset_run()
		hud.set_victory(false)
		_has_checkpoint = false
		_checkpoint_position = Vector2.ZERO
		_transitioning = true
		var tween := create_tween()
		tween.tween_property(fade, "modulate:a", 1.0, 0.3)
		await tween.finished
		_transitioning = false
		await _load_round(1, false)

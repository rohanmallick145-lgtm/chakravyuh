extends Node2D
## The Chakravyuha: the final boss. A giant living wheel that hides in the dark
## and spits celestial fire. Strike it while levitating (or at high rolling
## speed) to shatter its armour. Six hits break the wheel.

signal defeated(pos: Vector2)

const PROJECTILE_SCRIPT := preload("res://scripts/enemies/projectile.gd")

@export var max_hp := 6
@export var hover_radius := 255.0
@export var contact_damage := 10.0

var hp := 6
var _anchor := Vector2.ZERO
var _t := 0.0
var _player: Node2D
var _hit_cd := 0.0
var _attack_cd := 2.0
var _pattern := 0
var _dead := false
var _hitbox: Area2D
var _light: PointLight2D

func _ready() -> void:
	hp = max_hp
	_anchor = position
	_t = randf() * TAU
	_player = get_tree().get_first_node_in_group("player")

	_hitbox = Area2D.new()
	_hitbox.collision_layer = 4
	_hitbox.collision_mask = 2
	_hitbox.monitoring = true
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 82.0
	shape.shape = circle
	_hitbox.add_child(shape)
	add_child(_hitbox)
	_hitbox.body_entered.connect(_on_body_entered)

	_light = LightFactory.make_light(Color(1.0, 0.42, 0.18), 2.2, 2.4)
	_light.position = Vector2.ZERO
	add_child(_light)
	queue_redraw()

func _process(delta: float) -> void:
	if _dead:
		return
	_t += delta
	position = _anchor + Vector2(sin(_t * 0.55) * hover_radius, sin(_t * 1.05) * 42.0)
	_hit_cd = maxf(0.0, _hit_cd - delta)
	_attack_cd -= delta
	if _attack_cd <= 0.0:
		_attack_cd = 2.25
		_pattern = (_pattern + 1) % 3
		_attack(_pattern)
	queue_redraw()
	if _light:
		_light.energy = 2.0 + sin(_t * 3.0) * 0.45

func _attack(pattern: int) -> void:
	Sfx.play("orb", -11.0, randf_range(0.78, 0.96))
	match pattern:
		0:
			_radial(12, 185.0)
		1:
			_aimed_burst()
		2:
			_spiral()

func _radial(count: int, spd: float) -> void:
	var offset := _t * 0.8
	for i in count:
		var dir := Vector2.from_angle(offset + TAU * float(i) / float(count))
		_spawn_orb(global_position, dir, spd, Color(1.0, 0.38, 0.16))
	Burst.spawn(get_parent(), global_position, Color(1.0, 0.45, 0.2), 20, 260.0)

func _aimed_burst() -> void:
	if _player == null or not is_instance_valid(_player):
		return
	var base := global_position.direction_to(_player.global_position)
	for i in 3:
		var spread := (float(i) - 1.0) * 0.14
		_spawn_orb(global_position, base.rotated(spread), 330.0, Color(1.0, 0.72, 0.25))

func _spiral() -> void:
	for i in 10:
		if not is_inside_tree() or _dead:
			return
		var dir := Vector2.from_angle(_t * 3.0 + TAU * float(i) / 10.0)
		_spawn_orb(global_position, dir, 210.0, Color(1.0, 0.55, 0.3))
		await get_tree().create_timer(0.055).timeout

func _spawn_orb(pos: Vector2, dir: Vector2, spd: float, color: Color) -> void:
	var p := Area2D.new()
	p.set_script(PROJECTILE_SCRIPT)
	p.call("setup", dir, spd, 8.0, color, "orb", true)
	get_parent().add_child(p)
	p.global_position = pos

func _on_body_entered(body: Node) -> void:
	if _dead or not body.is_in_group("player"):
		return
	var levitating: bool = body.call("is_levitating")
	var v: Vector2 = body.get("linear_velocity")
	if levitating or v.length() > 430.0:
		_hit_by_player(body)
	else:
		body.call("take_damage", contact_damage, global_position)
		_bounce(body)

func _hit_by_player(body: Node) -> void:
	if _hit_cd > 0.0 or _dead:
		return
	_hit_cd = 0.65
	hp -= 1
	Sfx.play("boss_hit", -2.0, randf_range(0.94, 1.08))
	Burst.spawn(get_parent(), global_position, Color(1.0, 0.8, 0.35), 26, 330.0)
	body.call("add_shake", 0.8)
	_bounce(body)
	if _light:
		_light.energy = 4.0
	if visual_flash():
		pass
	if hp <= 0:
		_die()

func _bounce(body: Node) -> void:
	var dir := global_position.direction_to(body.global_position)
	if dir.length_squared() < 0.1:
		dir = Vector2.DOWN
	body.set("linear_velocity", dir * 520.0 + Vector2(0, -260.0))

func visual_flash() -> bool:
	var tween := create_tween()
	tween.tween_property(self, "modulate", Color(3, 2, 1, 1), 0.06)
	tween.tween_property(self, "modulate", Color.WHITE, 0.2)
	return true

func _die() -> void:
	_dead = true
	Sfx.play("boss_defeat", -1.0)
	_hitbox.set_deferred("monitoring", false)
	var spawn_pos := global_position
	Burst.spawn(get_parent(), global_position, Color(1.0, 0.8, 0.35), 50, 460.0)
	Burst.spawn(get_parent(), global_position, Color(0.9, 0.2, 0.1), 36, 300.0)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(self, "scale", Vector2(1.8, 1.8), 0.35)
	tween.tween_property(self, "modulate:a", 0.0, 0.35)
	await tween.finished
	defeated.emit(spawn_pos)
	queue_free()

func _draw() -> void:
	var gold := Color(0.95, 0.72, 0.28)
	var red := Color(0.85, 0.20, 0.12)
	var iron := Color(0.10, 0.08, 0.07)
	var eye := Color(1.0, 0.45, 0.15)

	draw_circle(Vector2.ZERO, 110.0, Color(1.0, 0.35, 0.1, 0.05))
	draw_circle(Vector2.ZERO, 88.0, Color(0.04, 0.03, 0.03, 0.92))

	# Twelve rotating blades.
	for i in 12:
		var a := _t * 0.35 + TAU * float(i) / 12.0
		var side := a + PI * 0.5
		var p1 := Vector2.from_angle(a) * 72.0
		var p2 := Vector2.from_angle(a) * 108.0
		var col := red if i % 2 == 0 else gold
		draw_colored_polygon(PackedVector2Array([
			p1 + Vector2.from_angle(side) * 9.0,
			p2,
			p1 - Vector2.from_angle(side) * 9.0,
		]), iron)
		draw_line(p1, p2, Color(col.r, col.g, col.b, 0.8), 1.6, true)

	# Rings.
	draw_arc(Vector2.ZERO, 84.0, 0.0, TAU, 64, gold, 5.0, true)
	draw_arc(Vector2.ZERO, 70.0, -_t * 1.1, -_t * 1.1 + TAU, 64, Color(red.r, red.g, red.b, 0.9), 3.0, true)
	draw_arc(Vector2.ZERO, 52.0, _t * 1.7, _t * 1.7 + TAU, 48, gold.darkened(0.25), 2.4, true)
	for i in 8:
		var a := -_t * 1.4 + TAU * float(i) / 8.0
		var p := Vector2.from_angle(a) * 61.0
		draw_circle(p, 2.8, Color(gold.r, gold.g, gold.b, 0.75))

	# The eye.
	var pulse := 1.0 + sin(_t * 4.0) * 0.10
	draw_circle(Vector2.ZERO, 28.0 * pulse, Color(0.05, 0.02, 0.01))
	draw_circle(Vector2.ZERO, 17.0 * pulse, eye)
	draw_circle(Vector2.ZERO, 7.0, Color(1.0, 0.95, 0.8))
	draw_arc(Vector2.ZERO, 28.0, 0.0, TAU, 32, gold, 2.0, true)

	# Remaining armour pips.
	for i in max_hp:
		var a := -PI * 0.5 + TAU * float(i) / float(max_hp)
		var p := Vector2.from_angle(a) * 96.0
		var on := i < hp
		draw_circle(p, 4.0, Color(1.0, 0.85, 0.4, 0.95) if on else Color(0.25, 0.12, 0.08, 0.5))

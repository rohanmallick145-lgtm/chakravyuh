extends Node2D
## Stationary archer / fire shaman. Aims at Arjun and fires in bursts.

const PROJECTILE_SCRIPT := preload("res://scripts/enemies/projectile.gd")

@export var interval := 2.0
@export var burst := 1
@export var projectile_speed := 280.0
@export var damage := 10.0
@export var flame := false

var _timer := 0.0
var _t := 0.0
var _aim := 0.0
var _player: Node2D
var _sprite: Sprite2D

func _ready() -> void:
	_timer = randf_range(0.4, interval)
	_t = randf() * TAU
	_player = get_tree().get_first_node_in_group("player")
	_sprite = EnemyArt.make(86.0, Vector2(0, -42))
	if flame:
		_sprite.modulate = Color(1.0, 0.86, 0.72)
	_sprite.flip_h = true
	add_child(_sprite)

func _process(delta: float) -> void:
	_t += delta
	_timer -= delta
	if _player and is_instance_valid(_player):
		_aim = global_position.direction_to(_player.global_position).angle()
		_sprite.flip_h = cos(_aim) < 0.0
	if _timer <= 0.0:
		_timer = interval
		_fire()
	queue_redraw()

func _fire() -> void:
	if _player == null or not is_instance_valid(_player):
		return
	if global_position.distance_to(_player.global_position) > 1150.0:
		return
	var muzzle := global_position + Vector2(0, -44)
	var base := muzzle.direction_to(_player.global_position + Vector2(0, -8))
	var count := maxi(1, burst)
	var color := Color(1.0, 0.55, 0.16) if flame else Color(0.92, 0.86, 0.72)
	for i in count:
		var spread := 0.0
		if count > 1:
			spread = (float(i) - float(count - 1) * 0.5) * 0.16
		var p := Area2D.new()
		p.set_script(PROJECTILE_SCRIPT)
		p.call("setup", base.rotated(spread), projectile_speed, damage, color, "orb" if flame else "arrow", flame)
		get_parent().add_child(p)
		p.global_position = muzzle
	var distance := global_position.distance_to(_player.global_position)
	var falloff := clampf(distance / 1150.0, 0.0, 1.0)
	Sfx.play("shoot", lerpf(-6.0, -22.0, falloff), randf_range(0.9, 1.08) if flame else randf_range(0.96, 1.05))
	Burst.spawn(get_parent(), muzzle, color, 5, 90.0)

func _draw() -> void:
	# The painted sprite is the body; keep the drawn bow so the unit still
	# telegraphs its aim and the flame shamans still read as fire casters.
	var trim := Color(1.0, 0.6, 0.2) if flame else Color(0.55, 0.65, 0.85)
	var d := Vector2.from_angle(_aim)
	var side := d.orthogonal()
	var center := Vector2(0, -34)
	draw_arc(center, 19.0, _aim - PI * 0.5, _aim + PI * 0.5, 20, trim.darkened(0.2), 2.2, true)
	draw_line(center + side * 19.0, center - side * 19.0, Color(0.85, 0.82, 0.7, 0.8), 1.0, true)
	draw_line(center, center + d * 16.0, trim, 2.0, true)
	draw_circle(center + d * 18.0, 2.4, Color(1.0, 0.9, 0.6))
	if flame:
		draw_circle(center, 12.0, Color(1.0, 0.45, 0.1, 0.10 + sin(_t * 7.0) * 0.04))

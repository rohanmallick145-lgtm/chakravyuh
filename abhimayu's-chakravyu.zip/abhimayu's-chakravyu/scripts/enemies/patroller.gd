extends Area2D
## A hovering asura guard. Contact hurts — unless Arjun hits it while
## levitating (or moving fast), in which case the celestial aura destroys it.

@export var patrol_range := 140.0
@export var speed := 80.0
@export var damage := 14.0

var _home := Vector2.ZERO
var _dir := 1.0
var _t := 0.0
var _dead := false
var _tick := 0.0
var _sprite: Sprite2D

func _ready() -> void:
	collision_layer = 4
	collision_mask = 2
	monitoring = true
	_home = position
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 25.0
	shape.shape = circle
	add_child(shape)
	body_entered.connect(_on_body_entered)
	_t = randf() * TAU
	_sprite = EnemyArt.make(74.0, Vector2(0, -2))
	add_child(_sprite)

func _process(delta: float) -> void:
	_t += delta
	position.x += _dir * speed * delta
	if position.x > _home.x + patrol_range:
		position.x = _home.x + patrol_range
		_dir = -1.0
	elif position.x < _home.x - patrol_range:
		position.x = _home.x - patrol_range
		_dir = 1.0
	position.y = _home.y + sin(_t * 2.4) * 5.0
	if _sprite:
		_sprite.flip_h = _dir < 0.0
	_sprite.rotation = sin(_t * 1.7) * 0.06
	queue_redraw()

func _physics_process(delta: float) -> void:
	_tick -= delta
	if _tick > 0.0 or _dead:
		return
	_tick = 0.4
	for body in get_overlapping_bodies():
		if body.is_in_group("player"):
			_hit_player(body)

func _on_body_entered(body: Node) -> void:
	if _dead or not body.is_in_group("player"):
		return
	_hit_player(body)

func _hit_player(player: Node) -> void:
	var vel: Vector2 = player.get("linear_velocity")
	var levitating: bool = player.call("is_levitating")
	if levitating or vel.length() > 420.0:
		_smite()
	else:
		player.call("take_damage", damage, global_position)

func _smite() -> void:
	_dead = true
	set_deferred("monitoring", false)
	Burst.spawn(get_parent(), global_position, Color(1.0, 0.6, 0.25), 22, 300.0)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(self, "scale", Vector2(1.6, 0.2), 0.22)
	tween.tween_property(self, "modulate:a", 0.0, 0.22)
	tween.chain().tween_callback(queue_free)

func _draw() -> void:
	# The painted sprite carries the body; only the celestial aura is drawn here.
	var gold := Color(0.85, 0.55, 0.20)
	draw_arc(Vector2.ZERO, 40.0, _t * 1.6, _t * 1.6 + PI * 0.9, 22,
		Color(gold.r, gold.g, gold.b, 0.32), 1.5, true)
	draw_arc(Vector2.ZERO, 44.0, -_t * 1.1, -_t * 1.1 + PI * 0.55, 16,
		Color(gold.r, gold.g, gold.b, 0.16), 1.0, true)

extends Area2D
## Projectile used by archers, fire shamans and the final boss.

@export var speed := 280.0
@export var damage := 10.0
@export var lifetime := 5.0
@export var color := Color(0.85, 0.9, 1.0)
@export_enum("arrow", "orb") var kind := "arrow"

var direction := Vector2.RIGHT
var _t := 0.0
var _dead := false
var _glow := false

func _ready() -> void:
	collision_layer = 4
	collision_mask = 2
	monitoring = true
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 10.0
	shape.shape = circle
	add_child(shape)
	body_entered.connect(_on_body_entered)
	rotation = direction.angle()
	_ready_glow()

func setup(dir: Vector2, p_speed: float, p_damage: float, p_color: Color, p_kind := "arrow", p_glow := false) -> void:
	direction = dir.normalized()
	speed = p_speed
	damage = p_damage
	color = p_color
	kind = p_kind
	_glow = p_glow

func _ready_glow() -> void:
	if _glow:
		var light := LightFactory.make_light(color, 1.5, 0.75)
		add_child(light)

func _process(delta: float) -> void:
	_t += delta
	lifetime -= delta
	if lifetime <= 0.0:
		queue_free()
		return
	position += direction * speed * delta
	queue_redraw()
	if kind == "orb":
		rotation += delta * 2.5

func _draw() -> void:
	if kind == "arrow":
		# Arrow shaft points along +X (node is rotated to the travel direction).
		draw_line(Vector2(-22, 0), Vector2(10, 0), color.darkened(0.35), 2.2, true)
		draw_colored_polygon(PackedVector2Array([
			Vector2(18, 0), Vector2(7, -5), Vector2(7, 5)
		]), color)
		draw_line(Vector2(-22, 0), Vector2(-16, -5), color, 1.6, true)
		draw_line(Vector2(-22, 0), Vector2(-16, 5), color, 1.6, true)
		draw_line(Vector2(-4, 0), Vector2(8, 0), Color(1, 1, 1, 0.55), 1.0, true)
	else:
		var pulse := 1.0 + sin(_t * 14.0) * 0.12
		draw_circle(Vector2.ZERO, 12.0 * pulse, Color(color.r, color.g, color.b, 0.18))
		draw_circle(Vector2.ZERO, 7.0 * pulse, color)
		draw_circle(Vector2.ZERO, 3.2, Color(1, 1, 1, 0.85))
		draw_arc(Vector2.ZERO, 11.0, _t * 5.0, _t * 5.0 + PI * 1.2, 16, Color(color.r, color.g, color.b, 0.7), 1.5, true)

func _on_body_entered(body: Node) -> void:
	if _dead or not body.is_in_group("player"):
		return
	_dead = true
	body.call("take_damage", damage, global_position)
	Burst.spawn(get_parent(), global_position, color, 10, 180.0)
	queue_free()

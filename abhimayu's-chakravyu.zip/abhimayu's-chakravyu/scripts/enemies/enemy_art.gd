class_name EnemyArt
extends RefCounted
## Shared painted enemy artwork. The source painting has been cut out of its
## white background, so each enemy only needs a per-unit height in pixels.

const TEXTURE := preload("res://assets/enemies/asura.png")

## Build a sprite whose drawn height is `height_px`, centred on `offset`.
## `show_behind_parent` keeps any hand-drawn effects (a bow, an aura) on top.
static func make(height_px: float, offset := Vector2.ZERO) -> Sprite2D:
	var sprite := Sprite2D.new()
	sprite.texture = TEXTURE
	sprite.centered = true
	sprite.show_behind_parent = true
	sprite.position = offset
	var s := height_px / float(TEXTURE.get_height())
	sprite.scale = Vector2(s, s)
	return sprite

extends Node2D
## Procedural art for Arjun's bronze sphere. No textures required.
## The node is a child of the RigidBody2D, so it spins as he rolls.

var radius := 24.0
var levitating := false
var levitation_charge := 0.0
var aura := 0.0
var _t := 0.0

func _process(delta: float) -> void:
	_t += delta
	aura = move_toward(aura, 0.0, delta * 1.8)
	queue_redraw()

func ping() -> void:
	aura = 1.0

func _draw() -> void:
	var gold := Color(0.96, 0.80, 0.42)
	var gold_hot := Color(1.0, 0.93, 0.68)
	var bronze := Color(0.18, 0.13, 0.09)
	var bronze_mid := Color(0.36, 0.25, 0.14)

	# Soft halo / levitation aura.
	var glow_a := 0.05 + aura * 0.18 + (0.10 if levitating else 0.0)
	draw_circle(Vector2.ZERO, radius + 15.0, Color(gold.r, gold.g, gold.b, glow_a))
	draw_circle(Vector2.ZERO, radius + 7.0, Color(gold.r, gold.g, gold.b, glow_a * 0.9))

	# Body.
	draw_circle(Vector2.ZERO, radius, bronze)
	draw_circle(Vector2.ZERO, radius - 3.0, bronze_mid)
	draw_circle(Vector2.ZERO, radius - 9.0, bronze)
	draw_arc(Vector2.ZERO, radius - 1.0, 0.0, TAU, 48, gold, 2.4, true)
	draw_arc(Vector2.ZERO, radius - 10.0, 0.0, TAU, 40, gold.darkened(0.25), 1.2, true)

	# Spokes make the rotation readable while rolling.
	for i in 3:
		var a := TAU * float(i) / 3.0 + sin(_t * 1.5) * 0.05
		var p1 := Vector2.from_angle(a) * 7.0
		var p2 := Vector2.from_angle(a) * (radius - 11.0)
		draw_line(p1, p2, Color(0.85, 0.65, 0.28, 0.55), 1.3, true)

	# Central celestial mark.
	draw_circle(Vector2.ZERO, 7.0, Color(0.05, 0.04, 0.03))
	draw_arc(Vector2.ZERO, 7.0, -PI * 0.85, PI * 0.55, 20, gold_hot, 1.6, true)
	draw_circle(Vector2(-1.5, -2.5), 2.2, gold_hot)

	# A travelling highlight.
	var ha := _t * 2.2
	var hp := Vector2.from_angle(ha) * (radius - 6.0)
	draw_circle(hp, 2.8, Color(1, 1, 1, 0.35 + 0.2 * sin(_t * 5.0)))

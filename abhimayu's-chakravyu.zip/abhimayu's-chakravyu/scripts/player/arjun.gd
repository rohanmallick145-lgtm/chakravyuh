extends RigidBody2D
## Arjun: a rolling RigidBody2D sphere.
## A / D -> torque + rolling assist, W -> jump then hold to levitate, S -> dive.
## Levitation duration and glide quality scale with GameState.ring_count.

@export var max_speed := 380.0
@export var jump_velocity := 780.0
@export var max_omega := 18.0
@export var roll_torque := 18000.0
@export var air_force := 950.0
@export var ground_assist := 1550.0
@export var levitation_rise := 135.0
@export var levitation_lift := 950.0
@export var coyote_time := 0.10
@export var jump_buffer_time := 0.12
@export var knockback := 430.0
@export var invincible_time := 0.95
@export var dive_gravity_scale := 1.8

var input_enabled := false
var is_dead := false
var is_invulnerable := false
var dark_mode := false
var level_ref: Node = null

var grounded := false
var levitating := false
var levitation_left := 0.0
var levitation_max := 0.5

var _axis := 0.0
var _w_held := false
var _w_prev := false
var _s_held := false
var _jump_buffer := 0.0
var _coyote := 0.0
var _invuln_left := 0.0
var _was_grounded := false
var _was_levitating := false
var _levitate_sfx_tick := 0.0
var _shake := 0.0
var _trail: Line2D
var _light: PointLight2D

@onready var visual: Node2D = get_node_or_null("Visual")
@onready var halo: Node2D = get_node_or_null("Halo")
@onready var camera: Camera2D = get_node_or_null("Camera2D")

func _ready() -> void:
	add_to_group("player")
	contact_monitor = true
	max_contacts_reported = 4
	can_sleep = false
	levitation_max = GameState.levitation_duration()
	levitation_left = levitation_max

	_light = LightFactory.make_light(Color(1.0, 0.86, 0.58), 1.5, 2.7)
	_light.enabled = false
	_light.z_index = 2
	add_child(_light)

	_trail = Line2D.new()
	_trail.top_level = true
	_trail.width = 18.0
	_trail.default_color = Color(1.0, 0.82, 0.40, 0.16)
	_trail.joint_mode = Line2D.LINE_JOINT_ROUND
	_trail.begin_cap_mode = Line2D.LINE_CAP_ROUND
	_trail.end_cap_mode = Line2D.LINE_CAP_ROUND
	_trail.antialiased = true
	_trail.z_index = 1
	add_child(_trail)
	_trail.top_level = true
	_trail.global_position = Vector2.ZERO
	_trail.global_rotation = 0.0

	GameState.ring_absorbed.connect(_on_ring_absorbed)

func _physics_process(delta: float) -> void:
	if freeze or is_dead:
		return

	levitation_max = GameState.levitation_duration()
	_grounded_check()

	if _invuln_left > 0.0:
		_invuln_left = maxf(0.0, _invuln_left - delta)
		if _invuln_left <= 0.0:
			is_invulnerable = false

	if grounded:
		_coyote = coyote_time
		if not _was_grounded and not levitating:
			_land_effect()
		levitation_left = levitation_max
		levitating = false
	else:
		_coyote = maxf(0.0, _coyote - delta)

	_axis = _read_axis() if input_enabled else 0.0
	_w_held = _read_w() if input_enabled else false
	_s_held = _read_s() if input_enabled else false

	if _w_held and not _w_prev and input_enabled:
		_jump_buffer = jump_buffer_time
	_w_prev = _w_held
	_jump_buffer = maxf(0.0, _jump_buffer - delta)

	# Gravity shaping: levitate, dive, or glide when out of levitation.
	if not grounded and _w_held and levitation_left > 0.0 and linear_velocity.y > -80.0:
		gravity_scale = 0.22
	elif not grounded and _s_held:
		gravity_scale = dive_gravity_scale
	elif not grounded and _w_held:
		gravity_scale = GameState.float_gravity_scale()
	else:
		gravity_scale = 1.0

	if is_invulnerable and visual:
		visual.modulate.a = 0.35 if int(Time.get_ticks_msec() / 70) % 2 == 0 else 1.0
	elif visual:
		visual.modulate.a = 1.0

	if level_ref and global_position.y > float(level_ref.get("kill_y")):
		die()

	_was_grounded = grounded
	_update_levitation_fx(delta)

func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
	if freeze or is_dead:
		return

	var v := state.linear_velocity
	var axis := _read_axis() if input_enabled else 0.0
	var w := _read_w() if input_enabled else false
	var s := _read_s() if input_enabled else false
	var just_jumped := false

	# Jump (buffered + coyote time).
	if _jump_buffer > 0.0 and _coyote > 0.0 and input_enabled:
		v.y = -jump_velocity
		_jump_buffer = 0.0
		_coyote = 0.0
		just_jumped = true
		add_shake(0.25)
		Sfx.play("jump", -3.0, randf_range(0.96, 1.05))

	# Ground rolling: a torque controller, plus a light velocity assist.
	if grounded:
		var target_omega := axis * max_omega
		if absf(axis) > 0.01:
			var torque := clampf((target_omega - state.angular_velocity) * 6200.0, -roll_torque, roll_torque)
			state.apply_torque(torque)
			v.x = move_toward(v.x, axis * max_speed, ground_assist * state.step)
		else:
			state.apply_torque(clampf(-state.angular_velocity * 5000.0, -roll_torque, roll_torque))
			v.x = move_toward(v.x, 0.0, ground_assist * 0.35 * state.step)
	else:
		state.apply_central_force(Vector2(axis * air_force * mass, 0.0))
		state.apply_torque(axis * roll_torque * 0.12)

	# Levitation: only after the upward jump arc has softened, so W still jumps.
	levitating = false
	if not grounded and w and not just_jumped and levitation_left > 0.0 and v.y > -80.0:
		levitating = true
		v.y = move_toward(v.y, -levitation_rise, levitation_lift * state.step)
		levitation_left = maxf(0.0, levitation_left - state.step)
	elif not grounded and w and levitation_left <= 0.0:
		v.y = maxf(v.y, 260.0)  # gentle glide once the rings are spent

	if s and not grounded and not levitating:
		v.y += 520.0 * state.step

	v.x = clampf(v.x, -max_speed * 1.2, max_speed * 1.2)
	v.y = clampf(v.y, -1500.0, 1700.0)
	state.linear_velocity = v
	state.angular_velocity = clampf(state.angular_velocity, -max_omega * 1.5, max_omega * 1.5)

func _process(delta: float) -> void:
	if halo:
		halo.global_position = global_position
		halo.global_rotation = 0.0
	if visual:
		visual.set("levitating", levitating)
		visual.set("levitation_charge", levitation_ratio())
	if camera:
		_shake = move_toward(_shake, 0.0, delta * 2.2)
		camera.offset = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * _shake * 14.0
	if _trail:
		if _trail.points.is_empty() or _trail.points[_trail.points.size() - 1].distance_to(global_position) > 5.0:
			_trail.add_point(global_position)
		while _trail.get_point_count() > 15:
			_trail.remove_point(0)
		_trail.default_color.a = 0.18 if not levitating else 0.30

func _grounded_check() -> void:
	var space := get_world_2d().direct_space_state
	var from := global_position
	var to := global_position + Vector2(0.0, 40.0)
	var query := PhysicsRayQueryParameters2D.create(from, to, 1, [get_rid()])
	var hit := space.intersect_ray(query)
	grounded = not hit.is_empty() and hit.normal.dot(Vector2.UP) > 0.5

func _read_axis() -> float:
	var left := Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)
	var right := Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT)
	return (1.0 if right else 0.0) - (1.0 if left else 0.0)

func _read_w() -> bool:
	return Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP) or Input.is_physical_key_pressed(KEY_SPACE)

func _read_s() -> bool:
	return Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN)

func levitation_ratio() -> float:
	if levitation_max <= 0.0:
		return 0.0
	return clampf(levitation_left / levitation_max, 0.0, 1.0)

func is_levitating() -> bool:
	return levitating

func set_dark_mode(enabled: bool) -> void:
	dark_mode = enabled
	if _light:
		_light.enabled = enabled
		_light.energy = 1.55
		_light.texture_scale = 2.8

func setup(level: Node) -> void:
	level_ref = level

func reset_at(pos: Vector2) -> void:
	global_position = pos
	linear_velocity = Vector2.ZERO
	angular_velocity = 0.0
	rotation = 0.0
	freeze = false
	sleeping = false
	visible = true
	is_dead = false
	is_invulnerable = false
	_invuln_left = 0.0
	input_enabled = false
	levitation_max = GameState.levitation_duration()
	levitation_left = levitation_max
	levitating = false
	_was_grounded = false
	_was_levitating = false
	_shake = 0.0
	if _trail:
		_trail.clear_points()
	if camera:
		camera.offset = Vector2.ZERO

func take_damage(amount: float, source := Vector2.ZERO) -> void:
	if is_dead or is_invulnerable:
		return
	is_invulnerable = true
	_invuln_left = invincible_time
	GameState.damage(amount)
	Sfx.play("damage", -2.0, randf_range(0.96, 1.04))
	add_shake(0.7)
	Burst.spawn(get_parent(), global_position, Color(1.0, 0.35, 0.25), 16, 240.0)

	var dir := global_position - source
	if dir.length_squared() < 1.0:
		dir = Vector2.UP
	dir = dir.normalized()
	apply_central_impulse((dir + Vector2.UP * 0.55).normalized() * knockback * mass)

	if GameState.hp <= 0.0:
		die()

func die() -> void:
	if is_dead:
		return
	is_dead = true
	input_enabled = false
	Sfx.play("death", -1.0)
	Burst.spawn(get_parent(), global_position, Color(1.0, 0.75, 0.35), 34, 360.0)
	add_shake(1.0)
	visible = false
	_light.enabled = false
	freeze = true
	GameState.kill_player()

func add_shake(amount: float) -> void:
	_shake = maxf(_shake, amount)

func _land_effect() -> void:
	var fall := absf(linear_velocity.y)
	if fall > 220.0:
		var weight := clampf(inverse_lerp(220.0, 900.0, fall), 0.0, 1.0)
		Sfx.play("land", lerpf(-17.0, -3.0, weight), randf_range(0.94, 1.06))
	if fall > 420.0:
		Burst.spawn(get_parent(), global_position + Vector2(0, 22), Color(0.8, 0.72, 0.55, 0.7), 8, 100.0)
		add_shake(0.15)

func _update_levitation_fx(delta: float) -> void:
	if levitating and not _was_levitating:
		Sfx.play("levitate", -6.0, randf_range(0.97, 1.04))
	_was_levitating = levitating
	if levitating:
		_levitate_sfx_tick -= delta
		if _levitate_sfx_tick <= 0.0:
			_levitate_sfx_tick = 0.09
			Burst.spawn(get_parent(), global_position + Vector2(0, 18), Color(1.0, 0.85, 0.45, 0.6), 2, 60.0)

func _on_ring_absorbed(_ring_number: int, _hp_lost: float) -> void:
	if visual and visual.has_method("ping"):
		visual.ping()
	if halo and halo.has_method("ping"):
		halo.ping()
	Burst.spawn(get_parent(), global_position, Color(1.0, 0.86, 0.42), 26, 320.0)
	add_shake(0.35)
	levitation_max = GameState.levitation_duration()
	levitation_left = levitation_max

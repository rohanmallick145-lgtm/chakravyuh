extends Node2D
## Golden ring orbits that grow with every absorbed celestial ring.
## Kept upright (top_level) while its parent RigidBody2D spins.

var _orbit := 0.0
var _pulse := 0.0
var _ring_count := 0

func _ready() -> void:
	top_level = true
	z_index = 3
	GameState.ring_count_changed.connect(_on_ring_count_changed)
	_ring_count = GameState.ring_count
	queue_redraw()

func _process(delta: float) -> void:
	_orbit += delta * 1.9
	_pulse = move_toward(_pulse, 0.0, delta * 2.5)
	queue_redraw()

func ping() -> void:
	_pulse = 1.0

func _on_ring_count_changed(count: int, _total: int) -> void:
	_ring_count = count
	queue_redraw()

func _draw() -> void:
	var gold := Color(1.0, 0.82, 0.40)
	var count := clampi(_ring_count, 0, 7)
	if count <= 0:
		return
	for i in count:
		var r := 33.0 + float(i) * 5.0
		var a := _orbit * (1.0 if i % 2 == 0 else -1.0) + TAU * float(i) / float(maxi(count, 1))
		var tilt := 0.34 + float(i) * 0.05 + _pulse * 0.08
		var center := Vector2(cos(a) * 5.0, sin(a) * 3.0)
		var col := gold
		col.a = 0.32 + 0.22 * sin(_orbit * 2.0 + float(i))
		draw_arc(center, r, a + tilt, a + tilt + PI * 1.25, 28, col, 2.0, true)
		var spark := center + Vector2.from_angle(a + tilt)
		draw_circle(center + Vector2.from_angle(a) * r, 1.8 + _pulse * 1.2, Color(1, 0.95, 0.75, col.a + 0.2))

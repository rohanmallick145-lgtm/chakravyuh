extends Control
## Painted, screen-space sky with layered parallax ridges and hand-placed
## landmarks for each round. Lives on its own CanvasLayer (layer -10) so the
## darkness of Round 7 does not erase it. Never uses randomness at draw time.

var data: Dictionary = {}
var camera: Camera2D = null
var round_index := 1
var level_length := 3600.0

var _t := 0.0
var _stars: Array[Vector3] = []
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_rng.seed = 1701 + round_index * 97
	_build_stars()

func setup(p_data: Dictionary, p_round: int, p_length: float) -> void:
	data = p_data
	round_index = p_round
	level_length = p_length
	_rng.seed = 1701 + round_index * 97
	_build_stars()
	queue_redraw()

func attach_camera(cam: Camera2D) -> void:
	camera = cam

func _build_stars() -> void:
	_stars.clear()
	var count := 0
	match round_index:
		4:
			count = 70
		3:
			count = 58
		5:
			count = 34
		_:
			count = 0
	for i in count:
		_stars.append(Vector3(
			_rng.randf_range(0.0, 1.0),
			_rng.randf_range(0.02, 0.55),
			_rng.randf_range(0.7, 1.9)
		))

func _process(delta: float) -> void:
	_t += delta
	queue_redraw()

func _camera_x() -> float:
	if camera != null and is_instance_valid(camera):
		return camera.get_screen_center_position().x
	return 0.0

## ------------------------------------------------------------------- draw

func _draw() -> void:
	var vw := size.x
	var vh := size.y
	if vw < 64.0 or vh < 64.0:
		var vr := get_viewport_rect().size
		vw = maxf(vw, vr.x)
		vh = maxf(vh, vr.y)
	if vw < 64.0:
		return

	if round_index == 7:
		# The final arena is deliberately pure black; only lights reveal it.
		draw_rect(Rect2(0, 0, vw, vh), Color.BLACK)
		return

	var cam := _camera_x()
	var top: Color = data.get("sky_top", Color("#0d1f26"))
	var bottom: Color = data.get("sky_bottom", Color("#2d5c63"))
	var accent: Color = data.get("accent", Color("#e8c66a"))
	var ground: Color = data.get("ground", Color("#17251f"))

	_draw_sky(vw, vh, top, bottom, accent)
	_draw_celestial(vw, vh, accent, cam)
	_draw_stars(vw, vh)
	_draw_clouds(vw, vh, bottom, accent, cam)

	# --- far distance ----------------------------------------------------
	_draw_ridge(vw, vh, 0.505, 0.030, 0.0021, 1.3, _far_col(bottom, accent), cam, 0.035)
	_draw_haze(vw, vh, 0.545, 0.10, bottom, accent)
	_draw_ridge(vw, vh, 0.575, 0.046, 0.0017, 4.1, _far_col(bottom, accent).darkened(0.12), cam, 0.070)
	_draw_round_far(vw, vh, accent, ground, cam)

	# --- middle distance -------------------------------------------------
	_draw_ridge(vw, vh, 0.645, 0.055, 0.0013, 2.2, ground.lerp(bottom, 0.24), cam, 0.125)
	_draw_haze(vw, vh, 0.665, 0.09, bottom, accent)
	_draw_round_mid(vw, vh, accent, ground, cam)

	# --- near / foreground ------------------------------------------------
	_draw_ridge(vw, vh, 0.735, 0.055, 0.00105, 5.7, ground.darkened(0.10), cam, 0.23)
	_draw_ridge(vw, vh, 0.835, 0.040, 0.00085, 0.8, ground.darkened(0.30), cam, 0.38)
	_draw_birds(vw, vh, accent, cam)
	_draw_motes(vw, vh, accent, cam)
	_draw_bottom_shade(vw, vh, ground)

func _draw_sky(vw: float, vh: float, top: Color, bottom: Color, accent: Color) -> void:
	var bands := 56
	for i in bands:
		var t := float(i) / float(bands - 1)
		var eased := pow(t, 1.42)
		var c := top.lerp(bottom, eased)
		# A warm horizon bloom, kept subtle so it reads as painted light.
		var bloom := clampf((t - 0.52) / 0.48, 0.0, 1.0) * (1.0 - clampf((t - 0.92) / 0.08, 0.0, 1.0))
		c = c.lerp(accent, bloom * 0.055)
		draw_rect(Rect2(0, vh * t - 1.0, vw, vh / float(bands) + 2.0), c)

	# Broad diagonal light shafts from the celestial body.
	var sx := vw * 0.72
	for i in 4:
		var w := 90.0 + float(i) * 65.0
		var a := 0.020 - float(i) * 0.004
		draw_colored_polygon(PackedVector2Array([
			Vector2(sx - w * 0.12, 0),
			Vector2(sx + w * 0.12, 0),
			Vector2(sx + w * 1.5, vh * 0.75),
			Vector2(sx - w * 0.5, vh * 0.75),
		]), Color(accent.r, accent.g, accent.b, a))

func _draw_celestial(vw: float, vh: float, accent: Color, cam: float) -> void:
	var spec := _celestial_spec()
	var cx := vw * float(spec[0]) + clampf(-cam * 0.018, -vw * 0.05, vw * 0.05)
	var cy := vh * float(spec[1])
	var radius := vh * float(spec[2])
	var body := accent.lerp(Color.WHITE, float(spec[3]))

	# Layered halo.
	for i in 6:
		var r := radius * (1.8 + float(i) * 0.55)
		var a := 0.055 * pow(0.72, float(i))
		draw_circle(Vector2(cx, cy), r, Color(accent.r, accent.g, accent.b, a))
	draw_circle(Vector2(cx, cy), radius * 1.03, Color(accent.r, accent.g, accent.b, 0.30))
	draw_circle(Vector2(cx, cy), radius, Color(body.r, body.g, body.b, 0.92))
	draw_circle(Vector2(cx, cy), radius * 0.72, Color(1.0, 0.98, 0.90, 0.55))

	# Horizontal haze stripes across the disc for a painted, not glossy, sun.
	for i in 7:
		var y := cy - radius + radius * 2.0 * float(i) / 7.0
		draw_rect(Rect2(cx - radius, y, radius * 2.0, radius * 0.055),
			Color(top_color().r, top_color().g, top_color().b, 0.12))

func _celestial_spec() -> Array:
	match round_index:
		1:
			return [0.74, 0.20, 0.080, 0.55]
		2:
			return [0.30, 0.42, 0.100, 0.35]
		3:
			return [0.76, 0.17, 0.060, 0.85]
		4:
			return [0.68, 0.22, 0.055, 0.80]
		5:
			return [0.72, 0.30, 0.090, 0.55]
		6:
			return [0.63, 0.49, 0.210, 0.35]
		_:
			return [0.72, 0.24, 0.070, 0.60]

func top_color() -> Color:
	return data.get("sky_top", Color("#0d1f26"))

func _draw_stars(vw: float, vh: float) -> void:
	if _stars.is_empty():
		return
	var accent: Color = data.get("accent", Color("#e8c66a"))
	var cam := _camera_x()
	for s in _stars:
		var x := s.x * vw - fposmod(cam * 0.008, 8.0)
		var y := s.y * vh
		var twinkle := 0.45 + 0.35 * sin(_t * 0.9 + float(int(s.x * 100.0)))
		var col := Color(0.86, 0.90, 1.0, twinkle * 0.7)
		draw_circle(Vector2(x, y), s.z, col)
		if s.z > 1.55:
			draw_circle(Vector2(x, y), s.z * 2.6, Color(col.r, col.g, col.b, col.a * 0.10))

func _draw_clouds(vw: float, vh: float, bottom: Color, accent: Color, cam: float) -> void:
	var tint := bottom.lerp(accent, 0.22)
	var alpha := 0.075
	match round_index:
		2:
			tint = Color(0.28, 0.14, 0.09)
			alpha = 0.12
		3:
			tint = bottom.lerp(Color(0.5, 0.35, 0.8), 0.4)
			alpha = 0.07
		6:
			tint = Color(1.0, 0.82, 0.5)
			alpha = 0.10
	for i in 7:
		var speed := 5.0 + float(i % 3) * 2.5
		var span := vw + 500.0
		var x := fposmod(float(i) * 311.0 + _t * speed - cam * 0.02, span) - 250.0
		var y := vh * (0.16 + 0.045 * float(i % 5)) + sin(_t * 0.08 + float(i)) * 6.0
		var w := 110.0 + float((i * 37) % 90)
		var h := 9.0 + float((i * 13) % 8)
		var a := alpha * (0.7 + 0.3 * sin(_t * 0.05 + float(i)))
		_ellipse(Vector2(x, y), Vector2(w, h), Color(tint.r, tint.g, tint.b, a))
		_ellipse(Vector2(x + w * 0.42, y - h * 0.35), Vector2(w * 0.55, h * 1.25),
			Color(tint.r, tint.g, tint.b, a * 0.8))
		_ellipse(Vector2(x - w * 0.38, y + h * 0.25), Vector2(w * 0.48, h * 0.8),
			Color(tint.r, tint.g, tint.b, a * 0.6))

	if round_index == 2:
		_draw_smoke(vw, vh, cam)

func _draw_smoke(vw: float, vh: float, cam: float) -> void:
	for i in 3:
		var x := vw * (0.18 + 0.24 * float(i)) + clampf(-cam * 0.05, -vw * 0.08, vw * 0.08)
		var base := vh * 0.62
		for j in 5:
			var t := float(j) / 4.0
			var r := 34.0 + t * 58.0
			var px := x + sin(_t * 0.22 + float(i) + t * 2.0) * 16.0 * t
			var py := base - t * vh * 0.34
			_ellipse(Vector2(px, py), Vector2(r, r * 0.55), Color(0.10, 0.05, 0.03, 0.16 * (1.0 - t * 0.55)))

func _draw_ridge(vw: float, vh: float, base_frac: float, amp_frac: float,
		freq: float, phase: float, color: Color, cam: float, factor: float) -> void:
	var shift := cam * factor
	var amp := vh * amp_frac
	var pts := PackedVector2Array()
	var step := 16.0
	var x := -48.0
	while x <= vw + 48.0:
		var wx := x + shift
		var y := vh * base_frac \
			+ sin(wx * freq + phase) * amp \
			+ sin(wx * freq * 2.17 + phase * 1.7) * amp * 0.40 \
			+ sin(wx * freq * 0.47 + phase * 0.6) * amp * 0.62
		pts.append(Vector2(x, y))
		x += step
	pts.append(Vector2(vw + 48.0, vh + 40.0))
	pts.append(Vector2(-48.0, vh + 40.0))
	draw_colored_polygon(pts, color)

	# Rim light along the crest.
	var rim := PackedVector2Array()
	for i in mini(pts.size(), 90):
		# Only the sampled crest, before the two bottom corners.
		if i < pts.size() - 2:
			rim.append(pts[i])
	if rim.size() > 2:
		draw_polyline(rim, Color(color.r + 0.06, color.g + 0.06, color.b + 0.06, 0.35), 1.0, true)

func _far_col(bottom: Color, accent: Color) -> Color:
	return bottom.lerp(accent, 0.14).darkened(0.35)

func _draw_haze(vw: float, vh: float, y_frac: float, height_frac: float, bottom: Color, accent: Color) -> void:
	var y := vh * y_frac
	var h := vh * height_frac
	var tint := bottom.lerp(accent, 0.3)
	for i in 5:
		var t := float(i) / 4.0
		var a := 0.075 * (1.0 - t) + 0.012
		draw_rect(Rect2(0, y + h * t * 0.5, vw, h * 0.22), Color(tint.r, tint.g, tint.b, a))

func _draw_bottom_shade(vw: float, vh: float, ground: Color) -> void:
	for i in 6:
		var t := float(i) / 5.0
		var a := 0.10 * (1.0 - t * 0.5)
		draw_rect(Rect2(0, vh - 70.0 + t * 12.0, vw, 12.0), Color(ground.r, ground.g, ground.b, a))

## ------------------------------------------------------------- landmarks

func _draw_round_far(vw: float, vh: float, accent: Color, ground: Color, cam: float) -> void:
	var shift := clampf(-cam * 0.075, -vw * 0.16, vw * 0.16)
	match round_index:
		1:
			_draw_gurukul(vw * 0.78 + shift, vh * 0.615, vh, Color(0.035, 0.075, 0.075, 0.95), accent)
		2:
			_draw_battlefield_flags(vw * 0.20 + shift, vh * 0.63, vh, Color(0.09, 0.045, 0.03, 0.9), accent)
		3:
			_draw_palace_far(vw * 0.25 + shift, vh * 0.62, vh, Color(0.055, 0.04, 0.10, 0.95), accent)
		4:
			_draw_battlefield_flags(vw * 0.30 + shift, vh * 0.64, vh, Color(0.05, 0.075, 0.12, 0.92), accent)
		5:
			_draw_wheel_shrine(vw * 0.76 + shift, vh * 0.60, vh, Color(0.09, 0.05, 0.03, 0.95), accent)
		6:
			_draw_sun_chariot(vw * 0.63 + shift, vh * 0.575, vh, Color(0.16, 0.08, 0.02, 0.92), accent)

func _draw_round_mid(vw: float, vh: float, accent: Color, ground: Color, cam: float) -> void:
	var shift := clampf(-cam * 0.16, -vw * 0.24, vw * 0.24)
	var sil := ground.darkened(0.18)
	match round_index:
		1:
			_draw_banyan(vw * 0.12 + shift, vh * 0.70, vh, sil, accent)
			_draw_banyan(vw * 0.90 + shift * 0.8, vh * 0.71, vh * 0.8, sil, accent)
		2:
			_draw_dead_tree(vw * 0.16 + shift, vh * 0.70, vh, sil, accent, true)
			_draw_dead_tree(vw * 0.40 + shift * 1.2, vh * 0.68, vh * 0.85, sil, accent, true)
			_draw_dead_tree(vw * 0.86 + shift * 0.9, vh * 0.71, vh, sil, accent, true)
		3:
			_draw_palace_near(vw * 0.80 + shift, vh * 0.70, vh, sil, accent)
			_draw_dice_tower(vw * 0.16 + shift, vh * 0.69, vh, sil, accent)
		4:
			_draw_broken_chariot(vw * 0.17 + shift, vh * 0.705, vh, sil, accent)
			_draw_spear_row(vw * 0.55 + shift, vh * 0.698, vh, sil, accent)
		5:
			_draw_fort_wall(vw * 0.15 + shift, vh * 0.70, vh, sil, accent)
			_draw_chakram(vw * 0.84 + shift, vh * 0.675, vh * 0.20, sil, accent)
		6:
			_draw_palm(vw * 0.11 + shift, vh * 0.705, vh, sil)
			_draw_palm(vw * 0.92 + shift, vh * 0.71, vh * 0.9, sil)

func _draw_gurukul(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	# Terrace.
	draw_rect(Rect2(x - 120.0 * s, base_y, 240.0 * s, 46.0 * s), col)
	draw_rect(Rect2(x - 130.0 * s, base_y - 5.0 * s, 260.0 * s, 6.0 * s), col.lightened(0.08))
	# Main dome and finial.
	_dome(Vector2(x, base_y - 6.0 * s), 56.0 * s, 44.0 * s, col)
	draw_line(Vector2(x, base_y - 50.0 * s), Vector2(x, base_y - 70.0 * s), col, 2.5 * s)
	draw_circle(Vector2(x, base_y - 72.0 * s), 3.2 * s, Color(accent.r, accent.g, accent.b, 0.7))
	# Side shrines.
	_dome(Vector2(x - 74.0 * s, base_y - 6.0 * s), 30.0 * s, 26.0 * s, col)
	_dome(Vector2(x + 74.0 * s, base_y - 6.0 * s), 30.0 * s, 26.0 * s, col)
	# Pillars.
	for i in 5:
		var px := x - 100.0 * s + float(i) * 50.0 * s
		draw_rect(Rect2(px - 4.0 * s, base_y - 22.0 * s, 8.0 * s, 22.0 * s), col)
	# Flag.
	draw_line(Vector2(x - 116.0 * s, base_y), Vector2(x - 116.0 * s, base_y - 92.0 * s), col, 2.0 * s)
	draw_colored_polygon(PackedVector2Array([
		Vector2(x - 116.0 * s, base_y - 92.0 * s),
		Vector2(x - 78.0 * s, base_y - 82.0 * s),
		Vector2(x - 116.0 * s, base_y - 70.0 * s),
	]), Color(accent.r, accent.g, accent.b, 0.30))
	# Tiny warm windows.
	for i in 3:
		var wx := x - 44.0 * s + float(i) * 44.0 * s
		draw_circle(Vector2(wx, base_y - 12.0 * s), 2.4 * s, Color(accent.r, accent.g, accent.b, 0.55))

func _draw_palace_far(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	draw_rect(Rect2(x - 150.0 * s, base_y, 300.0 * s, 54.0 * s), col)
	draw_rect(Rect2(x - 160.0 * s, base_y - 6.0 * s, 320.0 * s, 7.0 * s), col.lightened(0.06))
	# Stepped roof.
	for i in 4:
		var w := (150.0 - float(i) * 30.0) * s
		var y := base_y - 18.0 * s - float(i) * 17.0 * s
		draw_colored_polygon(PackedVector2Array([
			Vector2(x - w, y), Vector2(x, y - 26.0 * s), Vector2(x + w, y)
		]), col)
	# Gold lamps along the eave.
	for i in 7:
		var lx := x - 132.0 * s + float(i) * 44.0 * s
		var glow := Color(accent.r, accent.g, accent.b, 0.55)
		draw_circle(Vector2(lx, base_y + 24.0 * s), 3.4 * s, glow)
		draw_circle(Vector2(lx, base_y + 24.0 * s), 9.0 * s, Color(accent.r, accent.g, accent.b, 0.10))

func _draw_battlefield_flags(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	for i in 4:
		var px := x + float(i) * 58.0 * s
		var h := (86.0 + float(i % 3) * 22.0) * s
		draw_line(Vector2(px, base_y), Vector2(px, base_y - h), col, 2.2 * s)
		draw_colored_polygon(PackedVector2Array([
			Vector2(px, base_y - h),
			Vector2(px + 34.0 * s, base_y - h + 12.0 * s),
			Vector2(px, base_y - h + 26.0 * s),
		]), Color(accent.r, accent.g, accent.b, 0.22))
		draw_circle(Vector2(px, base_y - h - 3.0 * s), 2.0 * s, Color(accent.r, accent.g, accent.b, 0.5))

func _draw_wheel_shrine(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	# Fortification.
	draw_rect(Rect2(x - 60.0 * s, base_y, 120.0 * s, 50.0 * s), col)
	for i in 5:
		draw_rect(Rect2(x - 60.0 * s + float(i) * 25.0 * s, base_y - 9.0 * s, 15.0 * s, 9.0 * s), col)
	# Huge half-buried chakram.
	var c := Vector2(x, base_y + 6.0 * s)
	var r := 74.0 * s
	draw_arc(c, r, PI, TAU, 48, Color(accent.r, accent.g, accent.b, 0.24), 5.0 * s, true)
	draw_arc(c, r * 0.78, PI, TAU, 40, col.lightened(0.10), 3.0 * s, true)
	for i in 7:
		var a := PI + PI * float(i) / 6.0
		draw_line(c + Vector2.from_angle(a) * r * 0.80, c + Vector2.from_angle(a) * r,
			Color(accent.r, accent.g, accent.b, 0.22), 2.0 * s, true)

func _draw_sun_chariot(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	# Chariot body.
	draw_rect(Rect2(x - 34.0 * s, base_y - 18.0 * s, 68.0 * s, 18.0 * s), col)
	draw_arc(Vector2(x + 28.0 * s, base_y), 16.0 * s, 0.0, TAU, 24, col.lightened(0.10), 3.0 * s, true)
	for i in 6:
		var a := TAU * float(i) / 6.0
		draw_line(Vector2(x + 28.0 * s, base_y), Vector2(x + 28.0 * s, base_y) + Vector2.from_angle(a) * 14.0 * s,
			col.lightened(0.10), 1.4 * s, true)
	# Four horses as simple layered silhouettes.
	for i in 4:
		var hx := x - 54.0 * s - float(i) * 34.0 * s
		var body := Rect2(hx - 18.0 * s, base_y - 30.0 * s + float(i % 2) * 4.0 * s, 38.0 * s, 14.0 * s)
		draw_rect(body, col)
		draw_line(Vector2(hx + 18.0 * s, base_y - 24.0 * s), Vector2(hx + 34.0 * s, base_y - 40.0 * s), col, 5.0 * s, true)
		draw_line(Vector2(hx - 14.0 * s, base_y - 17.0 * s), Vector2(hx - 18.0 * s, base_y), col, 2.4 * s, true)
		draw_line(Vector2(hx + 10.0 * s, base_y - 17.0 * s), Vector2(hx + 16.0 * s, base_y), col, 2.4 * s, true)
	# Golden rein glow.
	draw_line(Vector2(x - 40.0 * s, base_y - 20.0 * s), Vector2(x - 150.0 * s, base_y - 26.0 * s),
		Color(accent.r, accent.g, accent.b, 0.25), 1.4 * s, true)

func _draw_banyan(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	# Trunk.
	draw_colored_polygon(PackedVector2Array([
		Vector2(x - 10.0 * s, base_y), Vector2(x - 6.0 * s, base_y - 42.0 * s),
		Vector2(x + 6.0 * s, base_y - 42.0 * s), Vector2(x + 11.0 * s, base_y)
	]), col)
	# Wide canopy.
	for i in 7:
		var ox := float(i - 3) * 18.0 * s
		var r := (30.0 - absf(float(i - 3)) * 4.0) * s
		draw_circle(Vector2(x + ox, base_y - 46.0 * s - absf(ox) * 0.08), r, col)
	# Aerial roots.
	for i in 5:
		var rx := x + float(i - 2) * 20.0 * s
		draw_line(Vector2(rx, base_y - 44.0 * s), Vector2(rx + 2.0 * s, base_y - 4.0 * s),
			Color(col.r, col.g, col.b, 0.65), 1.0 * s, true)
	# Gold fireflies in the canopy.
	for i in 4:
		var fx := x + float(i - 2) * 16.0 * s
		var fy := base_y - 48.0 * s + sin(_t * 0.7 + float(i)) * 4.0 * s
		draw_circle(Vector2(fx, fy), 1.4 * s, Color(accent.r, accent.g, accent.b, 0.4))

func _draw_dead_tree(x: float, base_y: float, vh: float, col: Color, accent: Color, burning: bool) -> void:
	var s := vh / 720.0
	var lean := sin(x * 0.01) * 8.0 * s
	# Trunk.
	draw_colored_polygon(PackedVector2Array([
		Vector2(x - 9.0 * s, base_y), Vector2(x - 4.0 * s + lean, base_y - 58.0 * s),
		Vector2(x + 4.0 * s + lean, base_y - 58.0 * s), Vector2(x + 9.0 * s, base_y)
	]), col)
	# Branches.
	var tips := [
		Vector2(-32.0, -92.0), Vector2(26.0, -104.0), Vector2(-14.0, -122.0),
		Vector2(40.0, -78.0), Vector2(8.0, -134.0),
	]
	for i in tips.size():
		var tip: Vector2 = tips[i]
		var start := Vector2(x + lean * 0.6, base_y - 56.0 * s)
		var end := Vector2(x + tip.x * s + lean, base_y + tip.y * s)
		draw_line(start, end, col, (3.2 - float(i) * 0.3) * s, true)
		draw_line(end, end + Vector2(-8.0, -10.0) * s, col, 1.5 * s, true)
		draw_line(end, end + Vector2(9.0, -8.0) * s, col, 1.5 * s, true)
	if burning:
		var glow := Color(1.0, 0.42, 0.10, 0.16)
		draw_circle(Vector2(x + lean, base_y - 70.0 * s), 46.0 * s, Color(glow.r, glow.g, glow.b, 0.07))
		draw_circle(Vector2(x + lean, base_y - 60.0 * s), 22.0 * s, Color(glow.r, glow.g, glow.b, 0.10))
		for i in 3:
			var fx := x + float(i - 1) * 8.0 * s + sin(_t * 2.0 + float(i)) * 3.0 * s
			var fy := base_y - 30.0 * s - fposmod(_t * 26.0 + float(i) * 22.0, 70.0) * s
			draw_circle(Vector2(fx, fy), 1.8 * s, Color(1.0, 0.55, 0.18, 0.7))

func _draw_palace_near(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	# Platform and pillars.
	draw_rect(Rect2(x - 120.0 * s, base_y - 6.0 * s, 240.0 * s, 46.0 * s), col)
	for i in 5:
		var px := x - 96.0 * s + float(i) * 48.0 * s
		draw_rect(Rect2(px - 5.0 * s, base_y - 76.0 * s, 10.0 * s, 70.0 * s), col)
		draw_rect(Rect2(px - 8.0 * s, base_y - 78.0 * s, 16.0 * s, 4.0 * s), col.lightened(0.08))
	# Architrave and roof.
	draw_rect(Rect2(x - 118.0 * s, base_y - 86.0 * s, 236.0 * s, 10.0 * s), col)
	draw_colored_polygon(PackedVector2Array([
		Vector2(x - 132.0 * s, base_y - 86.0 * s), Vector2(x, base_y - 128.0 * s),
		Vector2(x + 132.0 * s, base_y - 86.0 * s)
	]), col)
	# Hanging lamps.
	for i in 4:
		var lx := x - 72.0 * s + float(i) * 48.0 * s
		var ly := base_y - 56.0 * s + sin(_t * 0.6 + float(i)) * 1.5 * s
		draw_line(Vector2(lx, base_y - 78.0 * s), Vector2(lx, ly), Color(col.r, col.g, col.b, 0.8), 1.0 * s)
		draw_circle(Vector2(lx, ly + 4.0 * s), 2.8 * s, Color(accent.r, accent.g, accent.b, 0.7))
		draw_circle(Vector2(lx, ly + 4.0 * s), 9.0 * s, Color(accent.r, accent.g, accent.b, 0.08))

func _draw_dice_tower(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	draw_rect(Rect2(x - 26.0 * s, base_y - 120.0 * s, 52.0 * s, 120.0 * s), col)
	draw_rect(Rect2(x - 34.0 * s, base_y - 128.0 * s, 68.0 * s, 10.0 * s), col.lightened(0.08))
	draw_colored_polygon(PackedVector2Array([
		Vector2(x - 34.0 * s, base_y - 128.0 * s), Vector2(x, base_y - 156.0 * s),
		Vector2(x + 34.0 * s, base_y - 128.0 * s)
	]), col)
	# Dice pips as a subtle motif.
	for i in 4:
		var px := x - 12.0 * s + float(i % 2) * 24.0 * s
		var py := base_y - 92.0 * s + float(i / 2) * 24.0 * s
		draw_circle(Vector2(px, py), 3.0 * s, Color(accent.r, accent.g, accent.b, 0.22))

func _draw_broken_chariot(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	# Body and axle.
	draw_rect(Rect2(x - 44.0 * s, base_y - 34.0 * s, 70.0 * s, 18.0 * s), col)
	draw_line(Vector2(x + 22.0 * s, base_y - 18.0 * s), Vector2(x + 46.0 * s, base_y - 8.0 * s), col, 3.0 * s)
	# Wheels, one broken.
	_chariot_wheel(Vector2(x - 34.0 * s, base_y - 6.0 * s), 16.0 * s, col, accent, false)
	_chariot_wheel(Vector2(x + 34.0 * s, base_y - 6.0 * s), 16.0 * s, col, accent, true)
	# Broken shaft.
	draw_line(Vector2(x - 44.0 * s, base_y - 28.0 * s), Vector2(x - 72.0 * s, base_y - 10.0 * s), col, 2.0 * s)
	# Scattered arrows.
	for i in 3:
		var ax := x + 58.0 * s + float(i) * 14.0 * s
		draw_line(Vector2(ax, base_y), Vector2(ax - 8.0 * s, base_y - 26.0 * s), Color(col.r, col.g, col.b, 0.7), 1.2 * s)

func _chariot_wheel(pos: Vector2, r: float, col: Color, accent: Color, broken: bool) -> void:
	var col2 := col.lightened(0.10)
	draw_arc(pos, r, 0.0, TAU, 24, col2, 2.4, true)
	for i in 8:
		var a := TAU * float(i) / 8.0
		if broken and i % 3 == 0:
			continue
		draw_line(pos, pos + Vector2.from_angle(a) * r, col2, 1.2, true)
	draw_circle(pos, 2.4, Color(accent.r, accent.g, accent.b, 0.35))

func _draw_spear_row(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	for i in 9:
		var sx := x + float(i) * 17.0 * s
		var h := (40.0 + float((i * 7) % 20)) * s
		draw_line(Vector2(sx, base_y), Vector2(sx, base_y - h), col, 1.3 * s)
		draw_colored_polygon(PackedVector2Array([
			Vector2(sx, base_y - h), Vector2(sx - 2.5 * s, base_y - h + 7.0 * s),
			Vector2(sx + 2.5 * s, base_y - h + 7.0 * s)
		]), Color(accent.r, accent.g, accent.b, 0.22))

func _draw_fort_wall(x: float, base_y: float, vh: float, col: Color, accent: Color) -> void:
	var s := vh / 720.0
	draw_rect(Rect2(x - 130.0 * s, base_y - 34.0 * s, 260.0 * s, 74.0 * s), col)
	for i in 11:
		draw_rect(Rect2(x - 130.0 * s + float(i) * 25.0 * s, base_y - 46.0 * s, 15.0 * s, 13.0 * s), col)
	for i in 3:
		draw_circle(Vector2(x - 70.0 * s + float(i) * 70.0 * s, base_y - 12.0 * s), 3.0 * s,
			Color(accent.r, accent.g, accent.b, 0.45))

func _draw_chakram(x: float, y: float, r: float, col: Color, accent: Color) -> void:
	draw_arc(Vector2(x, y), r, 0.0, TAU, 56, col.lightened(0.08), r * 0.08, true)
	draw_arc(Vector2(x, y), r * 0.72, 0.0, TAU, 48, Color(accent.r, accent.g, accent.b, 0.16), r * 0.035, true)
	for i in 8:
		var a := TAU * float(i) / 8.0 + _t * 0.05
		draw_line(Vector2(x, y) + Vector2.from_angle(a) * r * 0.30,
			Vector2(x, y) + Vector2.from_angle(a) * r * 0.95,
			Color(col.r + 0.04, col.g + 0.04, col.b + 0.04, 0.9), r * 0.035, true)
	draw_circle(Vector2(x, y), r * 0.12, col.darkened(0.2))

func _draw_palm(x: float, base_y: float, vh: float, col: Color) -> void:
	var s := vh / 720.0
	var lean := 10.0 * s
	draw_colored_polygon(PackedVector2Array([
		Vector2(x - 5.0 * s, base_y), Vector2(x - 3.0 * s + lean, base_y - 82.0 * s),
		Vector2(x + 3.0 * s + lean, base_y - 82.0 * s), Vector2(x + 5.0 * s, base_y)
	]), col)
	for i in 6:
		var a := -PI * 0.5 + (float(i) - 2.5) * 0.42
		var tip := Vector2(x + lean, base_y - 82.0 * s) + Vector2.from_angle(a) * 34.0 * s
		draw_line(Vector2(x + lean, base_y - 82.0 * s), tip, col, 2.4 * s, true)
		draw_line(tip, tip + Vector2.from_angle(a + 0.5) * 12.0 * s, col, 1.4 * s, true)

func _dome(center: Vector2, radius: float, height: float, color: Color) -> void:
	var pts := PackedVector2Array()
	var steps := 18
	for i in steps + 1:
		var a := PI + PI * float(i) / float(steps)
		pts.append(center + Vector2(cos(a) * radius, sin(a) * height))
	pts.append(center + Vector2(radius, radius * 0.18))
	pts.append(center + Vector2(-radius, radius * 0.18))
	draw_colored_polygon(pts, color)

## --------------------------------------------------------------- particles

func _draw_birds(vw: float, vh: float, accent: Color, cam: float) -> void:
	if round_index == 2 or round_index == 4:
		return
	var base_speed := 7.0
	for i in 4:
		var x := fposmod(float(i) * 317.0 + _t * base_speed - cam * 0.05, vw + 300.0) - 150.0
		var y := vh * (0.26 + 0.03 * float(i)) + sin(_t * 0.5 + float(i)) * 5.0
		var s := 3.0 + float(i % 2) * 1.5
		var a := 0.20 + 0.10 * sin(_t * 0.7 + float(i))
		var col := Color(accent.r, accent.g, accent.b, a)
		draw_line(Vector2(x - s * 2.0, y), Vector2(x, y - s * 0.8), col, 1.0, true)
		draw_line(Vector2(x, y - s * 0.8), Vector2(x + s * 2.0, y), col, 1.0, true)

func _draw_motes(vw: float, vh: float, accent: Color, cam: float) -> void:
	var count := 26
	var rise := 9.0
	var col := accent
	match round_index:
		1:
			count = 22
			rise = 6.0
		2:
			count = 40
			rise = 34.0
			col = Color(1.0, 0.48, 0.14)
		3:
			count = 24
			rise = 5.0
		4:
			count = 18
			rise = 7.0
			col = Color(0.72, 0.84, 1.0)
		5:
			count = 26
			rise = 12.0
		6:
			count = 34
			rise = 22.0
			col = Color(1.0, 0.66, 0.22)
	for i in count:
		var seed_x := float((i * 733 + 151) % 1000) / 1000.0
		var x := fposmod(seed_x * vw - _t * (2.0 + float(i % 4)) - cam * 0.4, vw + 60.0) - 30.0
		var y := fposmod(float((i * 421 + 77) % 1000) / 1000.0 * (vh + 120.0) - _t * rise, vh + 120.0) - 60.0
		var a := 0.10 + 0.18 * (0.5 + 0.5 * sin(_t * 0.9 + float(i) * 1.7))
		var size := 0.9 + float(i % 4) * 0.35
		draw_circle(Vector2(x, y), size, Color(col.r, col.g, col.b, a))

## ---------------------------------------------------------------- helpers

func _ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
	draw_set_transform(center, 0.0, radii)
	draw_circle(Vector2.ZERO, 1.0, color)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

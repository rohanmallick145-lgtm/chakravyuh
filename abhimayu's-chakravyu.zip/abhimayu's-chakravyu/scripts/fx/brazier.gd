extends Node2D
## Flickering brazier for the dark arena. Adds a warm PointLight2D.

var _t := 0.0
var _light: PointLight2D

func _ready() -> void:
	_t = randf() * TAU
	_light = LightFactory.make_light(Color(1.0, 0.55, 0.22), 1.9, 1.55)
	_light.position = Vector2(0, -58)
	add_child(_light)
	queue_redraw()

func _process(delta: float) -> void:
	_t += delta
	queue_redraw()
	if _light:
		_light.energy = 1.75 + sin(_t * 8.3) * 0.28 + sin(_t * 21.7) * 0.12

func _draw() -> void:
	# Stand.
	draw_rect(Rect2(-12, -34, 24, 34), Color(0.10, 0.08, 0.07))
	draw_rect(Rect2(-17, -38, 34, 7), Color(0.22, 0.16, 0.10))
	draw_line(Vector2(-12, -10), Vector2(12, -10), Color(0.45, 0.32, 0.14), 2.0)
	# Bowl.
	draw_colored_polygon(PackedVector2Array([
		Vector2(-19, -46), Vector2(19, -46), Vector2(13, -34), Vector2(-13, -34)
	]), Color(0.16, 0.12, 0.08))
	# Flame.
	for layer in 3:
		var h := 30.0 - float(layer) * 7.0
		var w := 10.0 - float(layer) * 2.0
		var sway := sin(_t * 5.0 + float(layer) * 1.7) * 4.0
		draw_colored_polygon(PackedVector2Array([
			Vector2(-w, -46),
			Vector2(sway, -46 - h),
			Vector2(w, -46),
		]), [
			Color(1.0, 0.32, 0.06, 0.55),
			Color(1.0, 0.62, 0.14, 0.65),
			Color(1.0, 0.90, 0.55, 0.8),
		][layer])
	draw_circle(Vector2(sin(_t * 7.0) * 2.0, -52), 3.0, Color(1.0, 0.95, 0.75, 0.9))

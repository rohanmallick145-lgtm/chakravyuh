class_name LightFactory
extends RefCounted
## Cached soft radial texture for PointLight2D nodes created at runtime.

static var _radial: GradientTexture2D

static func radial_texture() -> GradientTexture2D:
	if _radial != null:
		return _radial
	var gradient := Gradient.new()
	gradient.offsets = PackedFloat32Array([0.0, 0.45, 1.0])
	gradient.colors = PackedColorArray([
		Color(1, 1, 1, 1),
		Color(1, 1, 1, 0.55),
		Color(1, 1, 1, 0),
	])
	_radial = GradientTexture2D.new()
	_radial.gradient = gradient
	_radial.width = 512
	_radial.height = 512
	_radial.fill = GradientTexture2D.FILL_RADIAL
	_radial.fill_from = Vector2(0.5, 0.5)
	_radial.fill_to = Vector2(1.0, 0.5)
	return _radial

static func make_light(color: Color, energy: float, scale: float) -> PointLight2D:
	var light := PointLight2D.new()
	light.texture = radial_texture()
	light.color = color
	light.energy = energy
	light.texture_scale = scale
	return light

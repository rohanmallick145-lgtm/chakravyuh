class_name Burst
extends RefCounted
## Lightweight one-shot particle bursts, created entirely in code.

static func spawn(parent: Node, pos: Vector2, color: Color, amount: int = 18, speed: float = 260.0) -> void:
	if parent == null or not parent.is_inside_tree():
		return
	var p := CPUParticles2D.new()
	p.position = pos
	p.amount = amount
	p.lifetime = 0.7
	p.one_shot = true
	p.explosiveness = 1.0
	p.direction = Vector2.UP
	p.spread = 180.0
	p.gravity = Vector2(0, 620)
	p.initial_velocity_min = speed * 0.35
	p.initial_velocity_max = speed
	p.scale_amount_min = 1.6
	p.scale_amount_max = 3.8
	p.color = color
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 7.0
	parent.add_child(p)
	p.emitting = true
	parent.get_tree().create_timer(1.4).timeout.connect(p.queue_free)

extends AnimatableBody2D
## Sine-eased moving platform. Set `platform_size`, `motion_offset`, `duration`
## before adding it to the scene.

@export var platform_size := Vector2(120, 20)
@export var motion_offset := Vector2(100, 0)
@export var duration := 3.0
@export var body_color := Color(0.22, 0.15, 0.10)
@export var edge_color := Color(0.85, 0.63, 0.30)

var _origin := Vector2.ZERO

func _ready() -> void:
	collision_layer = 1
	collision_mask = 0
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = platform_size
	shape.shape = rect
	add_child(shape)
	_origin = position
	var tween := create_tween().set_loops()
	tween.tween_property(self, "position", _origin + motion_offset, duration) \
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(self, "position", _origin, duration) \
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	queue_redraw()

func _draw() -> void:
	var r := Rect2(-platform_size * 0.5, platform_size)
	draw_rect(r, body_color)
	draw_rect(Rect2(r.position, Vector2(r.size.x, 5)), edge_color)
	draw_rect(r, edge_color.darkened(0.5), false, 2.0)
	for i in int(platform_size.x / 24.0):
		var x := r.position.x + 12.0 + float(i) * 24.0
		draw_line(Vector2(x, r.position.y + 7), Vector2(x, r.end.y - 2), edge_color.darkened(0.7), 1.0)
	draw_circle(Vector2(0, r.position.y + 10), 3.0, Color(1.0, 0.9, 0.6, 0.7))

extends Area2D
## Mid-level checkpoint: lights up, triggers a slow-motion story beat, and
## becomes the respawn point for the rest of the round.

signal activated

var used := false
var speaker := "Arjun"
var text := ""
var _t := 0.0
var _light: PointLight2D

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	_light = LightFactory.make_light(Color(0.6, 0.9, 1.0), 0.35, 0.8)
	_light.position = Vector2(0, -52)
	_light.enabled = false
	add_child(_light)
	queue_redraw()

func configure(p_speaker: String, p_text: String) -> void:
	speaker = p_speaker
	text = p_text

func _process(delta: float) -> void:
	_t += delta
	queue_redraw()

func set_dark_mode(enabled: bool) -> void:
	if _light:
		_light.enabled = enabled or used

func _draw() -> void:
	var col := Color(0.45, 0.9, 1.0) if used else Color(0.55, 0.48, 0.36)
	var gold := Color(1.0, 0.84, 0.45)
	# Obelisk.
	draw_colored_polygon(PackedVector2Array([
		Vector2(-16, 0), Vector2(-11, -78), Vector2(0, -98), Vector2(11, -78), Vector2(16, 0)
	]), Color(0.10, 0.10, 0.12))
	draw_polyline(PackedVector2Array([
		Vector2(-16, 0), Vector2(-11, -78), Vector2(0, -98), Vector2(11, -78), Vector2(16, 0)
	]), col.darkened(0.15), 2.0, true)
	# Rune.
	var a := 0.45 + 0.2 * sin(_t * 3.0)
	draw_arc(Vector2(0, -52), 10.0, _t, _t + PI * 1.4, 20, Color(col.r, col.g, col.b, a + 0.3), 2.5, true)
	draw_line(Vector2(-5, -52), Vector2(5, -52), Color(col.r, col.g, col.b, a), 1.5, true)
	draw_line(Vector2(0, -57), Vector2(0, -47), Color(col.r, col.g, col.b, a), 1.5, true)
	# Base.
	draw_rect(Rect2(-24, -6, 48, 6), Color(0.09, 0.08, 0.07))
	draw_line(Vector2(-24, -6), Vector2(24, -6), gold.darkened(0.5), 1.5)

func _on_body_entered(body: Node) -> void:
	if used or not body.is_in_group("player"):
		return
	used = true
	Sfx.play("checkpoint", -4.0)
	activated.emit()
	Burst.spawn(get_parent(), global_position + Vector2(0, -50), Color(0.55, 0.9, 1.0), 18, 180.0)
	if _light:
		_light.enabled = true

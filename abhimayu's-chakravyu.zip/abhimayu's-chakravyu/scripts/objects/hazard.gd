extends Area2D
## Spike strips and fire geysers. Damage is applied on entry and re-applied on
## a short tick if the player stays inside.

@export_enum("spikes", "fire") var kind := "spikes"
@export var size := Vector2(100, 24)
@export var damage := 18.0
@export var tint := Color(0.62, 0.68, 0.78)

var _t := 0.0
var _tick := 0.0
var _light: PointLight2D

func _ready() -> void:
	collision_layer = 8
	collision_mask = 2
	monitoring = true
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = size
	shape.shape = rect
	add_child(shape)
	body_entered.connect(_on_body_entered)
	_t = randf() * TAU
	if kind == "fire":
		_light = LightFactory.make_light(Color(1.0, 0.45, 0.15), 0.8, 0.7)
		_light.position = Vector2(0, -size.y * 0.5)
		add_child(_light)
	queue_redraw()

func _process(delta: float) -> void:
	if kind == "fire":
		_t += delta
		queue_redraw()
		if _light:
			_light.energy = 0.9 + sin(_t * 7.0) * 0.18

func _physics_process(delta: float) -> void:
	_tick -= delta
	if _tick > 0.0:
		return
	_tick = 0.28
	for body in get_overlapping_bodies():
		if body.is_in_group("player"):
			body.take_damage(damage, global_position)

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("player"):
		body.take_damage(damage, global_position)

func _draw() -> void:
	var half := size * 0.5
	if kind == "spikes":
		var count := maxi(3, int(size.x / 22.0))
		var step := size.x / float(count)
		for i in count:
			var x0 := -half.x + step * float(i)
			var p := PackedVector2Array([
				Vector2(x0, half.y),
				Vector2(x0 + step * 0.5, -half.y),
				Vector2(x0 + step, half.y),
			])
			draw_colored_polygon(p, Color(0.34, 0.38, 0.46))
			draw_polyline(p, Color(0.68, 0.74, 0.84, 0.8), 1.4, true)
			draw_line(Vector2(x0 + step * 0.5, -half.y), Vector2(x0 + step * 0.5, -half.y + 6), Color(1, 1, 1, 0.35), 1.0)
	else:
		# Layered animated flames.
		for layer in 3:
			var pts := PackedVector2Array()
			var n := 9
			for i in n + 1:
				var x := -half.x + size.x * float(i) / float(n)
				var h := half.y * (0.65 + 0.35 * sin(_t * 5.0 + float(i) * 1.3 + float(layer)))
				pts.append(Vector2(x, -h))
			pts.append(Vector2(half.x, half.y))
			pts.append(Vector2(-half.x, half.y))
			var col := Color(1.0, 0.35 + 0.18 * float(layer), 0.08, 0.35 + 0.18 * float(layer))
			draw_colored_polygon(pts, col)
		draw_rect(Rect2(-half, size), Color(0.35, 0.08, 0.03, 0.35))

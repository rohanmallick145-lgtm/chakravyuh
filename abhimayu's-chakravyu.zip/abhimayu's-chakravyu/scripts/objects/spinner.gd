extends Area2D
## Rotating chakram wheel hazard used in Round 5.

@export var radius := 46.0
@export var speed := 2.2
@export var damage := 20.0

var _t := 0.0
var _tick := 0.0

func _ready() -> void:
	collision_layer = 8
	collision_mask = 2
	monitoring = true
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = radius
	shape.shape = circle
	add_child(shape)
	body_entered.connect(_on_body_entered)
	_t = randf() * TAU

func _process(delta: float) -> void:
	_t += delta
	rotation += speed * delta
	position.y += sin(_t * 1.7) * 0.25
	queue_redraw()

func _physics_process(delta: float) -> void:
	_tick -= delta
	if _tick > 0.0:
		return
	_tick = 0.3
	for body in get_overlapping_bodies():
		if body.is_in_group("player"):
			body.take_damage(damage, global_position)

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("player"):
		body.take_damage(damage, global_position)

func _draw() -> void:
	var iron := Color(0.20, 0.16, 0.12)
	var gold := Color(0.85, 0.60, 0.26)
	var hot := Color(1.0, 0.55, 0.18, 0.7)
	draw_circle(Vector2.ZERO, radius + 10.0, Color(1.0, 0.55, 0.2, 0.06))
	for i in 8:
		var a := TAU * float(i) / 8.0
		var p1 := Vector2.from_angle(a) * (radius - 6.0)
		var p2 := Vector2.from_angle(a) * (radius + 13.0)
		var side := a + PI * 0.5
		draw_colored_polygon(PackedVector2Array([
			p1 + Vector2.from_angle(side) * 7.0,
			p2,
			p1 - Vector2.from_angle(side) * 7.0,
		]), iron)
		draw_line(p1, p2, gold.darkened(0.2), 1.2, true)
	draw_arc(Vector2.ZERO, radius, 0.0, TAU, 48, gold, 5.0, true)
	draw_arc(Vector2.ZERO, radius - 10.0, 0.0, TAU, 40, hot, 2.0, true)
	draw_circle(Vector2.ZERO, 9.0, Color(0.05, 0.04, 0.03))
	draw_circle(Vector2.ZERO, 4.0, hot)

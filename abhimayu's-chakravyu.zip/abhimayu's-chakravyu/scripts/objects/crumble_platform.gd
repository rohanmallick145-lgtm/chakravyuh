extends StaticBody2D
## Shakuni's collapsing stone. Touching it starts a short shake, then the
## platform vanishes for a few seconds before rebuilding.

@export var platform_size := Vector2(120, 22)
@export var rebuild_time := 3.0
@export var body_color := Color(0.18, 0.14, 0.22)
@export var edge_color := Color(0.66, 0.50, 0.90)

var _shape: CollisionShape2D
var _trigger: Area2D
var _home := Vector2.ZERO
var _falling := false

func _ready() -> void:
	collision_layer = 1
	collision_mask = 0
	_home = position

	_shape = CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = platform_size
	_shape.shape = rect
	add_child(_shape)

	_trigger = Area2D.new()
	_trigger.collision_layer = 32
	_trigger.collision_mask = 2
	var trigger_shape := CollisionShape2D.new()
	var trigger_rect := RectangleShape2D.new()
	trigger_rect.size = Vector2(platform_size.x, platform_size.y + 26.0)
	trigger_shape.shape = trigger_rect
	_trigger.add_child(trigger_shape)
	add_child(_trigger)
	_trigger.body_entered.connect(_on_body_entered)
	queue_redraw()

func _draw() -> void:
	var r := Rect2(-platform_size * 0.5, platform_size)
	draw_rect(r, body_color)
	draw_rect(Rect2(r.position, Vector2(r.size.x, 4)), edge_color)
	draw_rect(r, edge_color.darkened(0.55), false, 1.5)
	# Cracks so the player can read the trap.
	var mid := Vector2(0, r.position.y)
	draw_line(mid, mid + Vector2(-14, 7), edge_color.darkened(0.2), 1.4, true)
	draw_line(mid + Vector2(-14, 7), mid + Vector2(-6, 15), edge_color.darkened(0.2), 1.4, true)
	draw_line(mid, mid + Vector2(18, 5), edge_color.darkened(0.2), 1.4, true)

func _on_body_entered(body: Node) -> void:
	if _falling or not body.is_in_group("player"):
		return
	_collapse()

func _collapse() -> void:
	_falling = true
	Sfx.play("crumble", -6.0, randf_range(0.92, 1.06))
	var shake := create_tween()
	for i in 5:
		shake.tween_property(self, "position", _home + Vector2(randf_range(-3, 3), randf_range(-2, 2)), 0.05)
	shake.tween_property(self, "position", _home, 0.05)
	await shake.finished

	_shape.set_deferred("disabled", true)
	_trigger.set_deferred("monitoring", false)
	var fade := create_tween()
	fade.set_parallel(true)
	fade.tween_property(self, "modulate:a", 0.08, 0.2)
	fade.tween_property(self, "scale", Vector2(1.0, 0.6), 0.2)
	await fade.finished
	await get_tree().create_timer(rebuild_time).timeout
	if not is_inside_tree():
		return
	position = _home
	scale = Vector2.ONE
	_shape.set_deferred("disabled", false)
	_trigger.set_deferred("monitoring", true)
	var rebuild := create_tween()
	rebuild.tween_property(self, "modulate:a", 1.0, 0.3)
	await rebuild.finished
	_falling = false

extends Area2D
## Celestial ring pickup. Calls GameState.gain_ring(), which applies both the
## levitation buff and the permanent max-HP penalty.

signal collected(ring_number: int)

var _t := 0.0
var _base_pos := Vector2.ZERO
var _absorbed := false
var _dark := false
var _light: PointLight2D

func _ready() -> void:
	_base_pos = position
	_t = randf() * TAU
	body_entered.connect(_on_body_entered)
	_light = LightFactory.make_light(Color(1.0, 0.82, 0.35), 0.65, 1.2)
	_light.position = Vector2.ZERO
	_light.enabled = true
	add_child(_light)
	queue_redraw()

func _process(delta: float) -> void:
	_t += delta
	position.y = _base_pos.y + sin(_t * 2.1) * 6.0
	queue_redraw()
	if _light:
		_light.energy = (2.3 if _dark else 0.65) + sin(_t * 3.0) * 0.18

func _draw() -> void:
	var gold := Color(1.0, 0.84, 0.38)
	var hot := Color(1.0, 0.96, 0.78)
	var outer := 23.0 + sin(_t * 2.4) * 1.5

	draw_circle(Vector2.ZERO, outer + 13.0, Color(gold.r, gold.g, gold.b, 0.08))
	draw_circle(Vector2.ZERO, outer + 6.0, Color(gold.r, gold.g, gold.b, 0.12))
	draw_arc(Vector2.ZERO, outer, _t * 1.2, _t * 1.2 + PI * 1.45, 40, gold, 5.0, true)
	draw_arc(Vector2.ZERO, outer, _t * 1.2 + PI, _t * 1.2 + PI * 1.75, 24, gold.darkened(0.25), 3.0, true)
	draw_arc(Vector2.ZERO, outer - 7.0, -_t * 0.8, -_t * 0.8 + PI * 1.2, 28, Color(hot.r, hot.g, hot.b, 0.75), 1.6, true)

	for i in 4:
		var a := _t * 2.0 + TAU * float(i) / 4.0
		var p := Vector2.from_angle(a) * (outer + 9.0)
		var s := 2.2 + sin(_t * 4.0 + float(i)) * 1.1
		draw_colored_polygon(PackedVector2Array([
			p + Vector2(0, -s * 2.0), p + Vector2(s, 0), p + Vector2(0, s * 2.0), p + Vector2(-s, 0)
		]), Color(hot.r, hot.g, hot.b, 0.85))

func set_dark_mode(enabled: bool) -> void:
	_dark = enabled
	if _light:
		_light.energy = 2.3 if enabled else 0.65

func _on_body_entered(body: Node) -> void:
	if _absorbed or not body.is_in_group("player"):
		return
	_absorbed = true
	set_deferred("monitoring", false)
	set_deferred("monitorable", false)
	var result := GameState.ring_count + 1
	GameState.gain_ring()
	Sfx.play("ring", -2.0, 1.0 + 0.025 * float(result))
	Burst.spawn(get_parent(), global_position, Color(1.0, 0.88, 0.45), 34, 380.0)
	collected.emit(result)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(self, "scale", Vector2(2.2, 2.2), 0.35)
	tween.tween_property(self, "modulate:a", 0.0, 0.35)
	tween.chain().tween_callback(queue_free)

extends Area2D
## Level gate. Locked until the round's ring is claimed; emits `reached`.

signal reached

var unlocked := false
var _t := 0.0
var _dark := false
var _fired := false
var _light: PointLight2D

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	_light = LightFactory.make_light(Color(0.55, 0.85, 1.0), 0.5, 1.0)
	_light.position = Vector2(0, -55)
	add_child(_light)
	queue_redraw()

func _process(delta: float) -> void:
	_t += delta
	queue_redraw()
	if _light:
		_light.energy = (2.4 if unlocked else 0.35) + sin(_t * 2.5) * 0.2
		_light.color = Color(1.0, 0.85, 0.4) if unlocked else Color(0.7, 0.25, 0.2)

func set_unlocked(value: bool) -> void:
	unlocked = value
	queue_redraw()

func set_dark_mode(enabled: bool) -> void:
	_dark = enabled
	if _light:
		_light.enabled = enabled or unlocked
		if not enabled:
			_light.enabled = false

func _draw() -> void:
	var base := Vector2.ZERO
	var col := Color(0.45, 0.85, 1.0) if unlocked else Color(0.55, 0.18, 0.15)
	var glow := Color(1.0, 0.85, 0.42) if unlocked else Color(0.8, 0.25, 0.2)
	var alpha := 0.18 + 0.08 * sin(_t * 2.0)
	if unlocked:
		alpha += 0.12

	# Arch frame.
	draw_arc(base + Vector2(0, -52), 46.0, PI, TAU, 32, glow.darkened(0.15), 4.0, true)
	draw_line(base + Vector2(-46, -52), base + Vector2(-46, 0), glow.darkened(0.15), 5.0, true)
	draw_line(base + Vector2(46, -52), base + Vector2(46, 0), glow.darkened(0.15), 5.0, true)

	# Portal surface.
	if unlocked:
		for i in 4:
			var r := 34.0 - float(i) * 7.0 + sin(_t * 2.0 + float(i)) * 1.5
			draw_circle(base + Vector2(0, -52), r, Color(col.r, col.g, col.b, alpha * (0.5 + 0.15 * float(i))))
		for i in 6:
			var a := _t * 1.4 + TAU * float(i) / 6.0
			var p := base + Vector2(cos(a) * 30.0, -52.0 + sin(a) * 30.0)
			draw_circle(p, 2.2, Color(1, 0.95, 0.7, 0.7))
	else:
		draw_circle(base + Vector2(0, -52), 30.0, Color(col.r, col.g, col.b, alpha))
		# Chains across a sealed gate.
		for i in 3:
			var y := -26.0 - float(i) * 22.0
			draw_line(base + Vector2(-36, y), base + Vector2(36, y + 8), Color(0.45, 0.42, 0.38, 0.8), 3.0, true)
		draw_circle(base + Vector2(0, -55), 7.0, Color(0.05, 0.04, 0.03))
		draw_arc(base + Vector2(0, -55), 9.0, 0.0, TAU, 20, Color(0.65, 0.2, 0.16), 2.0, true)

	# Step / base.
	draw_rect(Rect2(base + Vector2(-54, -8), Vector2(108, 8)), Color(0.12, 0.10, 0.08))
	draw_line(base + Vector2(-54, -8), base + Vector2(54, -8), glow.darkened(0.3), 2.0)

func _on_body_entered(body: Node) -> void:
	if _fired or not body.is_in_group("player"):
		return
	if unlocked:
		_fired = true
		reached.emit()

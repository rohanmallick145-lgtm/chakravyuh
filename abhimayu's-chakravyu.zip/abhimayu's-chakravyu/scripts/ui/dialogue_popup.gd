extends CanvasLayer
## Cinematic story popup.
## - Round intro:    show_dialogue(..., {"pause": true})
## - Checkpoint hit:  show_dialogue(..., {"cinematic": true})  -> slow motion
## Typewriter runs on real time so it keeps typing while the tree is paused.

signal closed

const REVEAL_CPS := 52.0

## Speaker -> portrait. The supplied paintings are used for the elders, and
## Krishna gets his own final-round painting; younger warriors share a
## stylised archer portrait so the cast stays consistent.
const PORTRAIT_ELDER := preload("res://assets/portraits/elders.png")
const PORTRAIT_KRISHNA := preload("res://assets/portraits/krishna.png")
const PORTRAIT_KARNA := preload("res://assets/portraits/karna.png")
const PORTRAIT_WARRIOR := preload("res://assets/portraits/warrior.svg")
const ELDER_SPEAKERS := ["Dronacharya", "Drona", "Shakuni", "Bhishma", "Vidura", "Dhritarashtra"]
const KRISHNA_SPEAKERS := ["Krishna", "Vasudeva", "Govinda"]
const KARNA_SPEAKERS := ["Karna", "Radheya"]
const WARRIOR_SPEAKERS := ["Arjun", "Abhimanyu"]

@export var elder_portrait: Texture2D

@onready var root: Control = $Root
@onready var dimmer: ColorRect = $Root/Dimmer
@onready var panel: PanelContainer = $Root/Panel
@onready var portrait: TextureRect = $Root/Panel/Margin/HBox/PortraitFrame/Portrait
@onready var speaker_label: Label = $Root/Panel/Margin/HBox/TextCol/Speaker
@onready var body: RichTextLabel = $Root/Panel/Margin/HBox/TextCol/Body
@onready var prompt: Label = $Root/Panel/Margin/HBox/TextCol/Prompt

var is_open := false

var _typing := false
var _reveal := 0.0
var _last_ms := 0
var _pause_game := false
var _cinematic := false
var _time_scale_from := 1.0

func _ready() -> void:
	root.visible = false
	if elder_portrait:
		portrait.texture = elder_portrait
	process_mode = Node.PROCESS_MODE_ALWAYS

func show_dialogue(speaker: String, text: String, options := {}) -> void:
	if is_open:
		return
	is_open = true
	_pause_game = bool(options.get("pause", false))
	_cinematic = bool(options.get("cinematic", false))

	if options.has("portrait") and options.portrait is Texture2D:
		portrait.texture = options.portrait
	else:
		portrait.texture = _portrait_for(speaker)

	speaker_label.text = speaker
	body.text = text
	body.visible_characters = 0
	_reveal = 0.0
	_typing = true
	prompt.text = "[ SPACE ]  reveal"
	prompt.modulate.a = 0.55
	_last_ms = Time.get_ticks_msec()
	dimmer.color = Color(0, 0, 0, 0.62 if _pause_game else 0.34)

	root.visible = true
	root.modulate.a = 0.0
	Sfx.play("ui_open", -10.0)
	var tween := create_tween()
	tween.set_ignore_time_scale(true)
	tween.tween_property(root, "modulate:a", 1.0, 0.22)

	if _cinematic:
		_time_scale_from = Engine.time_scale
		Engine.time_scale = 0.22
	if _pause_game:
		get_tree().paused = true

func _process(_delta: float) -> void:
	if not is_open:
		return
	var now := Time.get_ticks_msec()
	var real_delta := clampf(float(now - _last_ms) / 1000.0, 0.0, 0.12)
	_last_ms = now

	if _typing:
		_reveal += real_delta * REVEAL_CPS
		body.visible_characters = int(_reveal)
		if body.visible_characters >= body.get_total_character_count():
			_finish_typing()
	else:
		prompt.modulate.a = 0.45 + 0.4 * sin(float(now) * 0.006)

func _finish_typing() -> void:
	_typing = false
	body.visible_characters = -1
	prompt.text = "[ SPACE ]  continue"

func _unhandled_input(event: InputEvent) -> void:
	if not is_open:
		return
	var accept := event.is_action_pressed("ui_accept") or event.is_action_pressed("ui_cancel")
	var click: bool = event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT
	if not accept and not click:
		return
	get_viewport().set_input_as_handled()
	if _typing:
		_finish_typing()
	else:
		_close()

func _portrait_for(speaker: String) -> Texture2D:
	for krishna in KRISHNA_SPEAKERS:
		if speaker.find(krishna) != -1:
			return PORTRAIT_KRISHNA
	for karna in KARNA_SPEAKERS:
		if speaker.find(karna) != -1:
			return PORTRAIT_KARNA
	for elder in ELDER_SPEAKERS:
		if speaker.find(elder) != -1:
			return PORTRAIT_ELDER
	for warrior in WARRIOR_SPEAKERS:
		if speaker.find(warrior) != -1:
			return PORTRAIT_WARRIOR
	return elder_portrait if elder_portrait != null else PORTRAIT_ELDER

func _close() -> void:
	is_open = false
	Sfx.play("ui_close", -10.0)
	root.visible = false
	if _pause_game:
		get_tree().paused = false
	if _cinematic:
		var tween := create_tween()
		tween.set_ignore_time_scale(true)
		tween.tween_method(_set_time_scale, Engine.time_scale, 1.0, 0.45)
	closed.emit()

func _set_time_scale(value: float) -> void:
	Engine.time_scale = maxf(0.01, value)

func _exit_tree() -> void:
	if _pause_game and get_tree():
		get_tree().paused = false
	Engine.time_scale = 1.0

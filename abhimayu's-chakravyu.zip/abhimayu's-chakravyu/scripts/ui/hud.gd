extends Control
## Fully procedural HUD: top-right health bar with permanent-cap cracks,
## celestial ring pips, levitation stamina, boss bar, toasts and victory screen.

var player: Node = null
var level: Node = null
var boss: Node = null
var round_index := 1
var victory := false

var _font: Font
var _banner_title := ""
var _banner_sub := ""
var _banner_time := 0.0
var _banner_total := 0.0
var _toast_text := ""
var _toast_time := 0.0
var _damage_flash := 0.0
var _hp_pulse := 0.0
var _hint_time := 0.0
var _time := 0.0

func _ready() -> void:
	_font = ThemeDB.fallback_font
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	GameState.hp_changed.connect(_on_hp_changed)
	GameState.ring_absorbed.connect(_on_ring_absorbed)
	GameState.ring_count_changed.connect(_on_ring_count_changed)
	GameState.player_died.connect(func() -> void: _damage_flash = 1.0)
	queue_redraw()

func _process(delta: float) -> void:
	_time += delta
	_banner_time = maxf(0.0, _banner_time - delta)
	_toast_time = maxf(0.0, _toast_time - delta)
	_damage_flash = move_toward(_damage_flash, 0.0, delta * 1.8)
	_hp_pulse = move_toward(_hp_pulse, 0.0, delta * 2.0)
	_hint_time = maxf(0.0, _hint_time - delta)
	queue_redraw()

func setup(p_level: Node, p_player: Node, index: int) -> void:
	level = p_level
	player = p_player
	round_index = index
	boss = null
	victory = false
	_hint_time = 10.0
	_banner_time = 0.0
	queue_redraw()

func set_level(p_level: Node, index: int) -> void:
	level = p_level
	round_index = index
	boss = null
	queue_redraw()

func set_boss(p_boss: Node) -> void:
	boss = p_boss
	queue_redraw()

func clear_boss() -> void:
	boss = null
	queue_redraw()

func show_round_banner(title: String, subtitle: String, hold := 2.8) -> void:
	_banner_title = title
	_banner_sub = subtitle
	_banner_time = hold
	_banner_total = hold
	queue_redraw()

func toast(text: String, hold := 3.4) -> void:
	_toast_text = text
	_toast_time = hold
	queue_redraw()

func set_victory(value: bool) -> void:
	victory = value
	queue_redraw()

func _on_hp_changed(_hp: float, _max_hp: float, _base: float) -> void:
	_damage_flash = maxf(_damage_flash, 0.5)
	_hp_pulse = 1.0
	queue_redraw()

func _on_ring_absorbed(ring_number: int, hp_lost: float) -> void:
	var suffix := ""
	if hp_lost > 0.01:
		suffix = "  −%.0f HP" % hp_lost
	toast("RING %d CLAIMED%s\nMax HP reduced · Levitation extended" % [ring_number, suffix], 4.2)
	_damage_flash = 1.0
	_hp_pulse = 1.0
	queue_redraw()

func _on_ring_count_changed(_count: int, _total: int) -> void:
	queue_redraw()

func _draw() -> void:
	if size.x <= 0.0 or size.y <= 0.0:
		return
	if victory:
		_draw_victory()
		return
	_draw_round_info()
	_draw_health()
	_draw_rings()
	_draw_levitation()
	_draw_boss()
	_draw_hint()
	_draw_toast()
	_draw_banner()
	_draw_damage_vignette()
	_draw_screen_cracks()

func _txt(pos: Vector2, text: String, font_size: int, color: Color, align := HORIZONTAL_ALIGNMENT_LEFT, width := -1.0) -> void:
	draw_string(_font, pos, text, align, width, font_size, color)

func _draw_round_info() -> void:
	var accent := Color(1.0, 0.82, 0.42)
	if level and level.get("data") != null:
		accent = level.data.get("accent", accent)
	var x := 30.0
	var y := 56.0
	draw_rect(Rect2(24, 26, 5, 58), accent)
	_txt(Vector2(x + 14, y), "ROUND %02d" % round_index, 15, Color(accent.r, accent.g, accent.b, 0.85))
	var name := DialogueData.get_round_name(round_index)
	if level and level.get("data") != null:
		name = level.data.get("name", name)
	_txt(Vector2(x + 14, y + 30), name.to_upper(), 22, Color(0.96, 0.93, 0.86))

	var objective := "Claim the ring · reach the gate"
	if GameState.has_claimed_ring(round_index):
		objective = "Gate unlocked · reach the gate"
	if round_index == 7:
		objective = "Break the wheel"
		if GameState.has_claimed_ring(7):
			objective = "The wheel is broken · reach the gate"
	_txt(Vector2(x + 14, 106), objective, 12, Color(0.78, 0.78, 0.74, 0.85))

func _draw_health() -> void:
	var w := 352.0
	var h := 30.0
	var x := size.x - w - 26.0
	var y := 58.0
	var bar := Rect2(x, y, w, h)
	var gold := Color(0.86, 0.70, 0.36)
	var dark := Color(0.04, 0.04, 0.05, 0.82)

	_txt(Vector2(x, y - 12.0), "ARJUN", 13, Color(0.92, 0.88, 0.78, 0.9))
	_txt(Vector2(x, y - 12.0), "HP  %d / %d" % [int(ceil(GameState.hp)), int(ceil(GameState.max_hp))],
		13, Color(0.96, 0.86, 0.66), HORIZONTAL_ALIGNMENT_RIGHT, w)

	draw_rect(bar, dark)
	draw_rect(bar, Color(gold.r, gold.g, gold.b, 0.55), false, 2.0)
	draw_rect(Rect2(bar.position + Vector2(3, 3), bar.size - Vector2(6, 6)), Color(0.0, 0.0, 0.0, 0.45))

	var cap_frac := GameState.max_hp_fraction()
	var hp_frac := GameState.hp_fraction()
	var inner := Rect2(bar.position + Vector2(3, 3), bar.size - Vector2(6, 6))
	var cap_x := inner.position.x + inner.size.x * cap_frac
	var fill_w := inner.size.x * clampf(hp_frac, 0.0, 1.0)

	# Permanent cap loss: scarred, cold area beyond the cap.
	if cap_frac < 0.999:
		var lost := Rect2(cap_x, inner.position.y, inner.end.x - cap_x, inner.size.y)
		draw_rect(lost, Color(0.10, 0.02, 0.02, 0.85))
		var sx := cap_x
		while sx < inner.end.x:
			draw_line(Vector2(sx, inner.position.y), Vector2(sx + 12, inner.end.y), Color(0.35, 0.12, 0.08, 0.5), 1.0)
			sx += 18.0

	# Current HP.
	var red := Color(0.82, 0.16, 0.12)
	var hot := Color(1.0, 0.42, 0.22)
	draw_rect(Rect2(inner.position, Vector2(fill_w, inner.size.y)), red)
	draw_rect(Rect2(inner.position, Vector2(fill_w, 3)), hot)
	var pulse := _hp_pulse * 0.35
	if pulse > 0.0:
		draw_rect(Rect2(inner.position, Vector2(fill_w, inner.size.y)), Color(1, 1, 1, pulse * 0.35))

	# Segment ticks.
	for i in range(1, 10):
		var tx := inner.position.x + inner.size.x * float(i) / 10.0
		draw_line(Vector2(tx, inner.position.y), Vector2(tx, inner.end.y), Color(0, 0, 0, 0.28), 1.0)

	# Cap fracture.
	if cap_frac < 0.999:
		draw_line(Vector2(cap_x, bar.position.y - 2), Vector2(cap_x, bar.end.y + 2), gold, 2.0)
		_draw_cracks(Vector2(cap_x, bar.position.y + h * 0.5), GameState.ring_count, gold)
		_txt(Vector2(cap_x - 46, bar.end.y + 14), "CAP %d" % int(ceil(GameState.max_hp)), 10, Color(0.9, 0.55, 0.3, 0.9))

func _draw_cracks(origin: Vector2, strength: int, color: Color) -> void:
	for i in mini(strength, 6):
		var dir := -1.0 if i % 2 == 0 else 1.0
		var off := origin + Vector2(dir * float(8 + i * 5), float(-6 + (i % 3) * 6))
		var pts := PackedVector2Array([
			off,
			off + Vector2(dir * 12.0, 7.0),
			off + Vector2(dir * 5.0, 15.0),
			off + Vector2(dir * 18.0, 21.0),
		])
		draw_polyline(pts, Color(color.r, color.g, color.b, 0.75), 1.2, true)

func _draw_rings() -> void:
	var w := 352.0
	var right := size.x - 26.0
	var x := right - w
	var y := 98.0
	_txt(Vector2(x, y + 10), "CELESTIAL RINGS  %d / 7" % GameState.ring_count, 11, Color(0.9, 0.82, 0.62, 0.85))
	var pip_start := right - 7.0 * 22.0 + 4.0
	for i in 7:
		var c := Vector2(pip_start + float(i) * 22.0, y + 28.0)
		if i < GameState.ring_count:
			draw_arc(c, 7.0, 0.0, TAU, 20, Color(1.0, 0.82, 0.38), 2.6, true)
			draw_circle(c + Vector2(0, -7), 1.8, Color(1.0, 0.95, 0.7, 0.9))
		else:
			draw_arc(c, 7.0, 0.0, TAU, 20, Color(0.35, 0.33, 0.28, 0.8), 1.4, true)

func _draw_levitation() -> void:
	if player == null or not is_instance_valid(player):
		return
	var w := 210.0
	var right := size.x - 26.0
	var x := right - w
	var y := 140.0
	var ratio: float = player.call("levitation_ratio")
	var levitating: bool = player.call("is_levitating")
	var col := Color(0.55, 0.85, 1.0) if levitating else Color(0.45, 0.62, 0.75)
	draw_rect(Rect2(x, y, w, 8), Color(0.04, 0.05, 0.07, 0.8))
	draw_rect(Rect2(x + 1, y + 1, (w - 2) * clampf(ratio, 0.0, 1.0), 6), col)
	draw_rect(Rect2(x, y, w, 8), Color(col.r, col.g, col.b, 0.45), false, 1.0)
	_txt(Vector2(x, y - 5), "LEVITATION  %.1fs" % (GameState.levitation_duration()), 10, Color(0.75, 0.82, 0.88, 0.8))

func _draw_boss() -> void:
	if boss == null or not is_instance_valid(boss):
		return
	var w := 540.0
	var x := (size.x - w) * 0.5
	var y := 32.0
	var hp: float = boss.get("hp")
	var max_hp: float = boss.get("max_hp")
	_txt(Vector2(x, y), "THE CHAKRAVYUHA", 12, Color(0.95, 0.72, 0.4), HORIZONTAL_ALIGNMENT_CENTER, w)
	draw_rect(Rect2(x, y + 10, w, 14), Color(0.03, 0.02, 0.02, 0.9))
	draw_rect(Rect2(x + 2, y + 12, (w - 4) * clampf(hp / max_hp, 0.0, 1.0), 10), Color(0.85, 0.22, 0.12))
	draw_rect(Rect2(x, y + 10, w, 14), Color(0.9, 0.65, 0.25, 0.65), false, 2.0)
	for i in int(max_hp) - 1:
		var tx := x + w * float(i + 1) / max_hp
		draw_line(Vector2(tx, y + 11), Vector2(tx, y + 23), Color(0, 0, 0, 0.55), 1.0)

func _draw_hint() -> void:
	if _hint_time <= 0.0:
		return
	var a := clampf(_hint_time / 2.0, 0.0, 1.0) * 0.8
	var y := size.y - 32.0
	_txt(Vector2(30, y), "A / D  roll     ·     W  jump, hold to levitate     ·     S  dive     ·     SPACE  continue",
		13, Color(0.92, 0.9, 0.82, a))

func _draw_toast() -> void:
	if _toast_time <= 0.0 or _toast_text.is_empty():
		return
	var a := clampf(_toast_time / 0.8, 0.0, 1.0)
	var lines := _toast_text.split("\n")
	var w := 560.0
	var x := (size.x - w) * 0.5
	var y := size.y - 120.0
	draw_rect(Rect2(x, y - 26, w, 28.0 + 20.0 * float(lines.size())), Color(0.02, 0.02, 0.03, 0.72 * a))
	draw_rect(Rect2(x, y - 26, w, 1.5), Color(0.95, 0.75, 0.35, 0.7 * a))
	for i in lines.size():
		var col := Color(0.98, 0.86, 0.55, a) if i == 0 else Color(0.82, 0.8, 0.74, a * 0.9)
		_txt(Vector2(x, y + 2.0 + float(i) * 20.0), lines[i], 15 if i == 0 else 12, col, HORIZONTAL_ALIGNMENT_CENTER, w)

func _draw_banner() -> void:
	if _banner_time <= 0.0:
		return
	var t := 1.0 - _banner_time / maxf(_banner_total, 0.01)
	var a := clampf(_banner_time / 0.5, 0.0, 1.0) * clampf(t / 0.2, 0.0, 1.0)
	var y := size.y * 0.33
	draw_rect(Rect2(0, y - 48, size.x, 96), Color(0.0, 0.0, 0.0, 0.45 * a))
	draw_line(Vector2(size.x * 0.32, y - 48), Vector2(size.x * 0.68, y - 48), Color(0.9, 0.72, 0.35, a), 1.0)
	_txt(Vector2(0, y), _banner_title, 34, Color(0.98, 0.94, 0.84, a), HORIZONTAL_ALIGNMENT_CENTER, size.x)
	_txt(Vector2(0, y + 28), _banner_sub, 14, Color(0.85, 0.75, 0.55, a), HORIZONTAL_ALIGNMENT_CENTER, size.x)

func _draw_damage_vignette() -> void:
	if _damage_flash <= 0.0:
		return
	var a := _damage_flash * 0.35
	var edge := 90.0
	draw_rect(Rect2(0, 0, size.x, edge), Color(0.6, 0.02, 0.02, a))
	draw_rect(Rect2(0, size.y - edge, size.x, edge), Color(0.6, 0.02, 0.02, a))
	draw_rect(Rect2(0, 0, edge, size.y), Color(0.6, 0.02, 0.02, a))
	draw_rect(Rect2(size.x - edge, 0, edge, size.y), Color(0.6, 0.02, 0.02, a))

func _draw_screen_cracks() -> void:
	var rings := GameState.ring_count
	if rings < 3:
		return
	var a := float(rings - 2) * 0.045
	var col := Color(0.95, 0.9, 0.8, a)
	var corners := [
		Vector2(size.x - 180, 160),
		Vector2(160, size.y - 200),
		Vector2(size.x - 120, size.y - 120),
	]
	for start in corners:
		var pts := PackedVector2Array([start])
		var p: Vector2 = start
		for i in 4:
			p += Vector2(-34.0 + float(i) * 9.0, 26.0 + float(i) * 7.0)
			pts.append(p)
		draw_polyline(pts, col, 1.2, true)

func _draw_victory() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.0, 0.0, 0.0, 0.86))
	var gold := Color(0.95, 0.78, 0.4)
	draw_arc(Vector2(size.x * 0.5, size.y * 0.36), 120.0, 0.0, TAU, 64, Color(gold.r, gold.g, gold.b, 0.25), 2.0)
	draw_arc(Vector2(size.x * 0.5, size.y * 0.36), 150.0, _time * 0.2, _time * 0.2 + PI * 1.4, 64, Color(gold.r, gold.g, gold.b, 0.16), 1.5)
	_txt(Vector2(0, size.y * 0.34), "THE WHEEL IS BROKEN", 42, gold, HORIZONTAL_ALIGNMENT_CENTER, size.x)
	_txt(Vector2(0, size.y * 0.42), "Seven rings claimed. The dark gives way.", 17, Color(0.88, 0.84, 0.74), HORIZONTAL_ALIGNMENT_CENTER, size.x)
	_txt(Vector2(0, size.y * 0.49), "Rings  %d / 7        Deaths  %d" % [GameState.ring_count, GameState.deaths], 14, Color(0.7, 0.68, 0.6), HORIZONTAL_ALIGNMENT_CENTER, size.x)
	var blink := 0.55 + 0.45 * sin(_time * 3.0)
	_txt(Vector2(0, size.y * 0.62), "PRESS SPACE TO WALK INTO THE NEW AGE", 15, Color(1, 0.92, 0.68, blink), HORIZONTAL_ALIGNMENT_CENTER, size.x)

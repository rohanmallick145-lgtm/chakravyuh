extends Node2D
class_name GameLevel
## One round. Geometry, hazards, enemies and pickups are built from LevelDB so
## every level stays data-driven and easy to retune.

signal ring_collected(ring_number: int)
signal checkpoint_reached(speaker: String, text: String)
signal exit_reached
signal boss_spawned(boss: Node)
signal boss_defeated

const RING_SCENE := preload("res://scenes/objects/ring.tscn")
const EXIT_SCENE := preload("res://scenes/objects/exit_portal.tscn")
const CHECKPOINT_SCENE := preload("res://scenes/objects/checkpoint.tscn")
const HAZARD_SCRIPT := preload("res://scripts/objects/hazard.gd")
const SPINNER_SCRIPT := preload("res://scripts/objects/spinner.gd")
const MOVER_SCRIPT := preload("res://scripts/objects/moving_platform.gd")
const CRUMBLE_SCRIPT := preload("res://scripts/objects/crumble_platform.gd")
const PATROLLER_SCRIPT := preload("res://scripts/enemies/patroller.gd")
const ARCHER_SCRIPT := preload("res://scripts/enemies/archer.gd")
const BOSS_SCRIPT := preload("res://scripts/enemies/boss.gd")
const BRAZIER_SCRIPT := preload("res://scripts/fx/brazier.gd")
const SKY_SCRIPT := preload("res://scripts/fx/sky_background.gd")

@export var round_index := 1

var data: Dictionary = {}
var spawn_position := Vector2(120, 500)
var respawn_position := Vector2(120, 500)
var kill_y := 900.0
var level_length := 3000.0
var is_dark := false
var player: Node = null
var ring: Node = null
var exit_portal: Node = null
var boss: Node = null
var sky: Control = null

var _checkpoints: Array[Node] = []
var _t := 0.0

func _ready() -> void:
	add_to_group("level")
	data = LevelDB.get_round(round_index)
	spawn_position = data.get("spawn", Vector2(120, 500))
	respawn_position = spawn_position
	kill_y = data.get("kill_y", 900.0)
	level_length = data.get("length", 3000.0)
	is_dark = data.get("dark", false)
	if is_dark:
		_apply_darkness()
	_build_collisions()
	_build_hazards()
	_build_movers()
	_build_crumbles()
	_build_spinners()
	_build_enemies()
	_build_ring()
	_build_checkpoints()
	_build_exit()
	_build_braziers()
	_build_boss()
	_build_sky()
	queue_redraw()

func _process(delta: float) -> void:
	_t += delta

## Called by the game manager after the player exists.
func setup_player(p: Node) -> void:
	player = p
	p.call("setup", self)
	p.call("set_dark_mode", is_dark)
	var cam := p.get_node_or_null("Camera2D")
	if cam:
		cam.limit_left = 0
		cam.limit_right = int(level_length)
		cam.limit_top = -520
		cam.limit_bottom = 840
		if sky:
			sky.call("attach_camera", cam)
	if ring:
		ring.call("set_dark_mode", is_dark)
	if exit_portal:
		exit_portal.call("set_dark_mode", is_dark)
	for cp in _checkpoints:
		cp.call("set_dark_mode", is_dark)

func get_spawn_position() -> Vector2:
	return spawn_position

func _apply_darkness() -> void:
	var modulate := CanvasModulate.new()
	modulate.color = Color(0.0, 0.0, 0.0)
	add_child(modulate)

	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_CANVAS
	env.glow_enabled = true
	env.glow_intensity = 0.85
	env.glow_bloom = 0.08
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_ADDITIVE
	env.glow_hdr_threshold = 0.85
	world_env.environment = env
	add_child(world_env)

func _build_collisions() -> void:
	for r in data.get("platforms", []):
		_add_static_rect(r)
	# Invisible side walls keep the sphere inside the level.
	_add_static_rect(Rect2(-60, -600, 60, 1600))
	_add_static_rect(Rect2(level_length, -600, 60, 1600))

func _add_static_rect(r: Rect2) -> void:
	var body := StaticBody2D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = r.position + r.size * 0.5
	var cs := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = r.size
	cs.shape = shape
	body.add_child(cs)
	add_child(body)

func _build_hazards() -> void:
	for r in data.get("spikes", []):
		_add_hazard("spikes", r)
	for r in data.get("fire", []):
		_add_hazard("fire", r)

func _add_hazard(kind: String, r: Rect2) -> void:
	var h := Area2D.new()
	h.set_script(HAZARD_SCRIPT)
	h.set("kind", kind)
	h.set("size", r.size)
	h.set("damage", 18.0 if kind == "spikes" else 14.0)
	h.position = r.position + r.size * 0.5
	add_child(h)

func _build_movers() -> void:
	for m in data.get("movers", []):
		var r: Rect2 = m.rect
		var body := AnimatableBody2D.new()
		body.set_script(MOVER_SCRIPT)
		body.set("platform_size", r.size)
		body.set("motion_offset", m.get("offset", Vector2.ZERO))
		body.set("duration", m.get("time", 3.0))
		body.position = r.position + r.size * 0.5
		add_child(body)

func _build_crumbles() -> void:
	for r in data.get("crumbles", []):
		var body := StaticBody2D.new()
		body.set_script(CRUMBLE_SCRIPT)
		body.set("platform_size", r.size)
		body.position = r.position + r.size * 0.5
		add_child(body)

func _build_spinners() -> void:
	for s in data.get("spinners", []):
		var area := Area2D.new()
		area.set_script(SPINNER_SCRIPT)
		area.set("radius", s.get("radius", 46.0))
		area.set("speed", s.get("speed", 2.2))
		area.position = s.pos
		add_child(area)

func _build_enemies() -> void:
	for p in data.get("patrollers", []):
		var area := Area2D.new()
		area.set_script(PATROLLER_SCRIPT)
		area.set("patrol_range", p.get("range", 140.0))
		area.set("speed", p.get("speed", 80.0))
		area.position = p.pos
		add_child(area)
	for a in data.get("archers", []):
		var archer := Node2D.new()
		archer.set_script(ARCHER_SCRIPT)
		archer.set("interval", a.get("interval", 2.0))
		archer.set("burst", a.get("burst", 1))
		archer.set("projectile_speed", a.get("speed", 280.0))
		archer.set("flame", a.get("flame", false))
		archer.position = a.pos
		add_child(archer)

func _build_ring() -> void:
	var ring_pos: Vector2 = data.get("ring", Vector2.ZERO)
	if ring_pos == Vector2.ZERO:
		return
	if GameState.has_claimed_ring(round_index):
		return
	ring = RING_SCENE.instantiate()
	ring.position = ring_pos
	add_child(ring)
	ring.connect("collected", _on_ring_picked)

func _build_checkpoints() -> void:
	var entries: Array = data.get("checkpoints", [])
	for i in entries.size():
		var entry: Dictionary = entries[i]
		var cp := CHECKPOINT_SCENE.instantiate()
		cp.position = entry.pos
		cp.call("configure", entry.get("speaker", "Arjun"), entry.get("text", ""))
		var seen := GameState.has_seen_checkpoint(round_index, i)
		cp.set("used", seen)
		add_child(cp)
		_checkpoints.append(cp)
		if not seen:
			cp.connect("activated", _on_checkpoint_activated.bind(cp, entry, i))

func _build_exit() -> void:
	exit_portal = EXIT_SCENE.instantiate()
	exit_portal.position = data.get("exit", Vector2(level_length - 150, 600))
	add_child(exit_portal)
	exit_portal.connect("reached", _on_exit_reached)
	var unlocked := GameState.has_claimed_ring(round_index)
	if round_index == 7:
		unlocked = GameState.has_claimed_ring(7)
	exit_portal.call("set_unlocked", unlocked)

func _build_braziers() -> void:
	for pos in data.get("braziers", []):
		var brazier := Node2D.new()
		brazier.set_script(BRAZIER_SCRIPT)
		brazier.position = pos
		add_child(brazier)

func _build_boss() -> void:
	if round_index != 7:
		return
	if GameState.has_claimed_ring(7):
		return
	var arena := Node2D.new()
	arena.set_script(BOSS_SCRIPT)
	arena.position = data.get("boss_anchor", Vector2(level_length * 0.5, 260))
	boss = arena
	add_child(arena)
	arena.connect("defeated", _on_boss_defeated)
	call_deferred("_announce_boss")

func _announce_boss() -> void:
	if boss and is_instance_valid(boss):
		boss_spawned.emit(boss)

func _on_ring_picked(ring_number: int) -> void:
	if exit_portal:
		exit_portal.call("set_unlocked", true)
	Sfx.play("gate", -3.0)
	ring_collected.emit(ring_number)

func _on_checkpoint_activated(cp: Node, entry: Dictionary, index: int) -> void:
	respawn_position = cp.position + Vector2(0, -80)
	GameState.mark_checkpoint_seen(round_index, index)
	checkpoint_reached.emit(entry.get("speaker", "Arjun"), entry.get("text", ""))

func _on_exit_reached() -> void:
	exit_reached.emit()

func _on_boss_defeated(pos: Vector2) -> void:
	boss = null
	boss_defeated.emit()
	Burst.spawn(self, pos, Color(1.0, 0.8, 0.4), 30, 380.0)
	ring = RING_SCENE.instantiate()
	ring.position = pos
	add_child(ring)
	ring.call("set_dark_mode", true)
	ring.connect("collected", _on_ring_picked)

## ---------------------------------------------------------------- background

func _build_sky() -> void:
	# Screen-space painted backdrop on its own canvas layer. The layer sits at
	# -10 so Round 7's CanvasModulate blacks out the world canvas without ever
	# touching the sky or the HUD.
	var layer := CanvasLayer.new()
	layer.layer = -10
	add_child(layer)
	sky = Control.new()
	sky.set_script(SKY_SCRIPT)
	layer.add_child(sky)
	sky.call("setup", data, round_index, level_length)

func _draw() -> void:
	for r in data.get("platforms", []):
		_draw_platform(r)

func _draw_platform(r: Rect2) -> void:
	var ground: Color = data.get("ground", Color("#17251f"))
	var edge: Color = data.get("ground_edge", Color("#4f7f60"))
	var accent: Color = data.get("accent", Color("#e8c66a"))
	draw_rect(r, ground)
	draw_rect(Rect2(r.position, Vector2(r.size.x, 6.0)), edge)
	draw_rect(r, edge.darkened(0.55), false, 2.0)
	draw_line(Vector2(r.position.x, r.end.y - 2.0), Vector2(r.end.x, r.end.y - 2.0), Color(0, 0, 0, 0.35), 3.0)
	var step := 72.0
	var x := r.position.x + step
	while x < r.end.x - 4.0:
		draw_line(Vector2(x, r.position.y + 8.0), Vector2(x, r.end.y - 3.0), edge.darkened(0.72), 1.0)
		x += step
	# Sparse glowing runes along the top edge.
	var rune_step := 190.0
	var rx := r.position.x + 95.0
	while rx < r.end.x - 20.0:
		draw_arc(Vector2(rx, r.position.y + 15.0), 6.0, 0.0, TAU, 14, Color(accent.r, accent.g, accent.b, 0.16), 1.0)
		rx += rune_step

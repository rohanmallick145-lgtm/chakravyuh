shader_type canvas_item;
render_mode blend_mix;

// A quiet, warm vignette plus a whisper of canvas grain. Sits on its own
// CanvasLayer above the world but below the HUD so it unifies the painted
// sky and the geometry without touching the interface.

uniform float strength : hint_range(0.0, 1.0) = 0.42;
uniform float grain_amount : hint_range(0.0, 0.12) = 0.035;
uniform vec3 tint : source_color = vec3(0.018, 0.014, 0.020);

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void fragment() {
	vec2 centered = (UV - 0.5) * vec2(1.0, 1.16);
	float vignette = smoothstep(0.30, 0.86, length(centered) * 1.30);
	float grain = (hash(FRAGCOORD.xy) - 0.5) * grain_amount * (0.25 + vignette);
	COLOR = vec4(tint + grain, vignette * strength);
}
